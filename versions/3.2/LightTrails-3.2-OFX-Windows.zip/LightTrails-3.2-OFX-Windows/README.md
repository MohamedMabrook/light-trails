# Light Trails 3.2: OpenFX for DaVinci Resolve

## New in 3.2: an on-screen reticle for Direction

The plugin now draws its own orange reticle in Resolve's viewer:

- **Toward Point:** the reticle *is* the point. Drag it anywhere in the frame and every trail heads there.
- **Angle:** the reticle sits on a ring around the frame centre, with a line and arrowhead showing the trail direction. Drag it around the ring to aim the trails. The Angle slider follows, and moving the slider moves the reticle.
- **Other directions:** the reticle is hidden.

Grab it within about 20 screen pixels; clicks anywhere else are left to Resolve. While you drag, it turns white.

If the reticle doesn't appear, the log (`%TEMP%\LightTrails.log` on Windows, `~/Library/Logs/LightTrails.log` on Mac) will say whether Resolve reported no on-screen overlay support. The Point X/Y and Angle fields always work.

Everything else is as in 3.1, and renders identically.

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the installer at https://github.com/MohamedMabrook/light-trails. 3.1 stays available there (branch `backup-v3.1`).
