// Micro-benchmark: kStreak / kComp alone, single thread, min of N runs. Same kernels as the plugin.
#include "../src/LightTrailsKernels.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <algorithm>
using namespace ltk;
int main(int argc, char** argv)
{
    const int W = 576, H = 270;     // Mac Medium processing size for a 1440x675 frame
    std::vector<float> hk(W * H * 4), acc(W * H * 4), src(1440 * 675 * 4), out(1440 * 675 * 4);
    FILE* f = fopen("synth/frame_039.f32", "rb");
    std::vector<float> full(1440 * 675 * 4); fread(full.data(), 4, full.size(), f); fclose(f);
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {          // crude key of the downscaled frame
        const float* p = &full[((y * 675 / H) * 1440 + x * 1440 / W) * 4];
        float k = keyBase(p[0], p[1], p[2], 0.8f, 0.1f, 0);
        float* o = &hk[(y * W + x) * 4]; o[0] = p[0] * k; o[1] = p[1] * k; o[2] = p[2] * k; o[3] = k;
    }
    StreakArgs a; memset(&a, 0, sizeof a);
    a.hk = {hk.data(), W, H, W * 4}; a.acc = {acc.data(), W, H, W * 4};
    a.mode = 0; a.steps = 24; a.riseC = 0.9945f; a.riseS = 0.1045f; a.centerX = W * 0.5f; a.len = 0.12f * W;
    a.decayK = 1.95f; a.norm = (a.len / a.steps) / (0.01f * W); a.amp = 8; a.freq = 1.5f; a.ph = 5.85f;
    a.thick = 0.6f; a.spread = 4; a.smoke = 0.5f; a.smokeScale = 32; a.hR = a.hG = a.hB = a.tR = a.tG = a.tB = 1;
    a.varScale = 24; a.emberScale = 2.4f;
    CompArgs c; memset(&c, 0, sizeof c);
    c.src = {full.data(), 1440, 675, 1440 * 4}; c.acc = a.acc; c.mask = a.acc; c.dst = {out.data(), 1440, 675, 1440 * 4};
    c.useAcc = 1; c.gain = 1; c.warm = 0.2f; c.soft = 0.5f; c.flickSpeed = 1; c.kThresh = 0.8f; c.kSoft = 0.1f; c.ftime = 39;
    struct Case { const char* n; float var, diss, fringe, flick; } cases[] = {
        {"off", 0, 0, 0, 0}, {"variation", 0.7f, 0, 0, 0}, {"dissolve", 0, 0.45f, 0, 0},
        {"fringe", 0, 0, 3, 0}, {"flicker (lamps)", 0, 0, 0, 0.5f}, {"all", 0.7f, 0.45f, 3, 0.5f}};
    double base = 0;
    for (auto& cs : cases) {
        a.variation = cs.var; a.dissolve = cs.diss; c.fringe = cs.fringe; c.flicker = cs.flick;
        double best = 1e9;
        for (int r = 0; r < 7; ++r) {
            auto t0 = std::chrono::steady_clock::now();
            for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) kStreak(x, y, a);
            for (int y = 0; y < 675; ++y) for (int x = 0; x < 1440; ++x) kComp(x, y, c);
            best = std::min(best, std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count());
        }
        if (!base) base = best;
        printf("%-16s %7.1f ms  (%+.0f%%)\n", cs.n, best, (best / base - 1) * 100);
    }
}
