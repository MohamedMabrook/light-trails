// LightTrailsKernels.h
// Per-pixel kernels. Compiled as CUDA device code (clang -x cuda, no SDK headers) for the
// plugin, and as plain C++ by the test driver. Images are RGBA, row 0 = bottom.
// View  = float RGBA with a row pitch (so Resolve's own CUDA buffers can be read directly).
// HView = half-float RGBA (frame cache: half the VRAM).
#pragma once

// The same source also compiles as Metal Shading Language (Mac): LT_G marks pointers into GPU
// memory ("device" in MSL, nothing elsewhere). LT_LITE (Mac) enables the cheaper streak path.
#if defined(__METAL_VERSION__)
#  define LT_DEV static inline
#  define LT_G device
#  define LT_I64 long
#  define LT_PCONST constant
#  define LT_T thread
#  define LT_EXP(x)   exp(x)
#  define LT_FLOOR(x) floor(x)
#  define LT_CEIL(x)  ceil(x)
#  define LT_SQRT(x)  sqrt(x)
#  define LT_FABS(x)  fabs(x)
#else
#  if defined(__CUDA__) && defined(__CUDA_ARCH__)
#    define LT_DEV __attribute__((device)) static inline
#    define LT_EXP(x) __nvvm_ex2_approx_f((x) * 1.44269504f)
#  else
#    define LT_DEV static inline
#    include <cmath>
#    define LT_EXP(x) expf(x)
#  endif
#  define LT_G
#  define LT_I64 long long
#  define LT_PCONST static const
#  define LT_T
#  define LT_FLOOR(x) __builtin_floorf(x)
#  define LT_CEIL(x)  __builtin_ceilf(x)
#  define LT_SQRT(x)  __builtin_sqrtf(x)
#  define LT_FABS(x)  __builtin_fabsf(x)
#endif

namespace ltk {

struct View  { LT_G float* d; int w, h, pitch; };            // pitch in floats
struct HView { LT_G unsigned short* d; int w, h, pitch; };   // pitch in halfs

struct F4 { float x, y, z, w; };

// ---- argument blocks -------------------------------------------------------------------
// depthMode: 0 none (depth = 1), 1 = luma of the depth view, 2 = alpha of the source
struct ResampleArgs { View src, depth; HView dst; int depthMode; };
struct FpArgs       { HView src; View dst; };
struct KeyArgs      { HView src; View dst; float thresh, soft; int colored, useDepth; float dLo, dHi, dFeather; int invert;
                      float flicker, flickSpeed, ftime; };
struct DownArgs     { View src, dst; int fdiv; float gain; };
struct BlurArgs     { View src, dst; int dx, dy, radius; float sigma; };
struct GradArgs     { View bo, bn, fl, dst; int mode, useFlow; };
struct SolveArgs    { View p1, p2, fl, dst; int useFlow; float lim; };
struct PrepArgs     { View fl, bo, bn, dst; };
struct SmokeArgs    { View dst; float scale, ph, age; };
struct SmearArgs {
    View acc, hk, fs, g0, g1;
    int first, useSmoke, echo, stride, frames, samples;
    float weight, flowScale, amp, freq, ph, thick, spread, driftX, driftY, smoke;
    float hR, hG, hB, tR, tG, tB;     // colour at the light (head) and at the tail
    float variation, varScale, dissolve, emberScale;
};
// Static streak: a trail grown from every hot point in a set direction (no history needed).
// mode 0 inward (toward the frame's vertical centre line), 1 outward, 2 fixed direction (dirX, dirY)
struct StreakArgs {
    View hk, acc;
    int mode, steps;
    float dirX, dirY, riseC, riseS, centerX, len, decayK, norm;
    float amp, freq, ph, thick, spread, smoke, smokeScale;
    float hR, hG, hB, tR, tG, tB;     // colour at the light (head) and at the tail
    float variation, varScale, dissolve, emberScale;
};
// dst pixel (x, y) reads src pixel (x + offX, y + offY); trails/mask are sampled in src coords
struct CompArgs { View src, acc, mask, dst; int offX, offY, useAcc, showMask, blend; float gain, warm, soft;
                  float fringe, flicker, flickSpeed, ftime, kThresh, kSoft; int kColored; };

LT_PCONST int SMOKE_CELL = 4;

// ---- helpers ---------------------------------------------------------------------------
LT_DEV LT_G float* vpx(LT_T const View& v, int x, int y) { return v.d + (LT_I64)y * v.pitch + (LT_I64)x * 4; }
LT_DEV LT_G unsigned short* hpx(LT_T const HView& v, int x, int y) { return v.d + (LT_I64)y * v.pitch + (LT_I64)x * 4; }

#if defined(__METAL_VERSION__)
LT_DEV unsigned int f2u(float f) { return as_type<uint>(f); }
LT_DEV float u2f(unsigned int u) { return as_type<float>(u); }
#else
LT_DEV unsigned int f2u(float f) { union { float f; unsigned int u; } c; c.f = f; return c.u; }
LT_DEV float u2f(unsigned int u) { union { float f; unsigned int u; } c; c.u = u; return c.f; }
#endif

// float <-> IEEE half (round to nearest, denormals flushed, clamps to inf)
LT_DEV unsigned short f2h(float f)
{
    unsigned int x = f2u(f);
    unsigned int sign = (x >> 16) & 0x8000u;
    int e = (int)((x >> 23) & 0xffu) - 127 + 15;
    unsigned int m = x & 0x7fffffu;
    if (e <= 0) return (unsigned short)sign;
    if (e >= 31) return (unsigned short)(sign | 0x7c00u);
    unsigned int h = sign | ((unsigned int)e << 10) | (m >> 13);
    if (m & 0x1000u) h += 1;                       // round (carry into exponent is correct)
    return (unsigned short)h;
}
LT_DEV float h2f(unsigned short h)
{
    unsigned int s = (unsigned int)(h & 0x8000u) << 16, e = (h >> 10) & 0x1fu, m = h & 0x3ffu;
    if (e == 0) return u2f(s);
    if (e == 31) return u2f(s | 0x7f800000u | (m << 13));
    return u2f(s | ((e - 15 + 127) << 23) | (m << 13));
}

LT_DEV float ltSat(float x) { return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x); }
LT_DEV float smooth(float e0, float e1, float x)
{
    if (e1 <= e0) return x < e0 ? 0.0f : 1.0f;
    float t = ltSat((x - e0) / (e1 - e0));
    return t * t * (3.0f - 2.0f * t);
}

LT_DEV float ltHash(int x, int y, int s)
{
    unsigned int h = ((unsigned int)x * 73856093u) ^ ((unsigned int)y * 19349663u) ^ ((unsigned int)s * 83492791u);
    h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
    return (float)(h & 0xFFFFu) / 65535.0f;
}

LT_DEV float fsin(float x)
{
    const float INV_TAU = 0.15915494f, TAU = 6.2831853f, PI = 3.14159265f, HPI = 1.57079633f;
    x -= TAU * LT_FLOOR(x * INV_TAU + 0.5f);
    if (x > HPI) x = PI - x; else if (x < -HPI) x = -PI - x;
    float x2 = x * x;
    return x * (1.0f + x2 * (-1.6666667e-1f + x2 * (8.3333333e-3f + x2 * (-1.9841270e-4f + x2 * 2.7557319e-6f))));
}

LT_DEV float ltLattice(float x, float y)
{
    unsigned int h = ((unsigned int)(int)x * 0x8da6b343u) ^ ((unsigned int)(int)y * 0xd8163841u);
    h ^= h >> 15; h *= 0x2c1b3c6du; h ^= h >> 12; h *= 0x297a2d39u; h ^= h >> 15;
    return (float)(h & 0xFFFFFFu) * (2.0f / 16777215.0f) - 1.0f;
}

LT_DEV float ltNoise(float x, float y)
{
    float ix = LT_FLOOR(x), iy = LT_FLOOR(y);
    float fx = x - ix, fy = y - iy;
    float ux = fx * fx * (3.0f - 2.0f * fx), uy = fy * fy * (3.0f - 2.0f * fy);
    float a = ltLattice(ix, iy), b = ltLattice(ix + 1.0f, iy);
    float c = ltLattice(ix, iy + 1.0f), d = ltLattice(ix + 1.0f, iy + 1.0f);
    float ab = a + (b - a) * ux, cd = c + (d - c) * ux;
    return ab + (cd - ab) * uy;
}

LT_DEV F4 texel(LT_T const View& t, int x, int y)
{
    F4 r = {0.0f, 0.0f, 0.0f, 0.0f};
    if (x < 0 || y < 0 || x >= t.w || y >= t.h) return r;
    LT_G const float* p = vpx(t, x, y);
    r.x = p[0]; r.y = p[1]; r.z = p[2]; r.w = p[3];
    return r;
}

// Bilinear, border = 0, pixel centres at +0.5
LT_DEV F4 ltS(LT_T const View& t, float px, float py)
{
    float fx = px - 0.5f, fy = py - 0.5f;
    float flx = LT_FLOOR(fx), fly = LT_FLOOR(fy);
    int x0 = (int)flx, y0 = (int)fly;
    float ax = fx - flx, ay = fy - fly;
    float w00 = (1 - ax) * (1 - ay), w10 = ax * (1 - ay), w01 = (1 - ax) * ay, w11 = ax * ay;
    F4 r;
    if (x0 >= 0 && y0 >= 0 && x0 + 1 < t.w && y0 + 1 < t.h) {
        LT_G const float* p0 = vpx(t, x0, y0);
        LT_G const float* p1 = p0 + t.pitch;
        r.x = p0[0] * w00 + p0[4] * w10 + p1[0] * w01 + p1[4] * w11;
        r.y = p0[1] * w00 + p0[5] * w10 + p1[1] * w01 + p1[5] * w11;
        r.z = p0[2] * w00 + p0[6] * w10 + p1[2] * w01 + p1[6] * w11;
        r.w = p0[3] * w00 + p0[7] * w10 + p1[3] * w01 + p1[7] * w11;
        return r;
    }
    F4 a = texel(t, x0, y0), b = texel(t, x0 + 1, y0), c = texel(t, x0, y0 + 1), d = texel(t, x0 + 1, y0 + 1);
    r.x = a.x * w00 + b.x * w10 + c.x * w01 + d.x * w11;
    r.y = a.y * w00 + b.y * w10 + c.y * w01 + d.y * w11;
    r.z = a.z * w00 + b.z * w10 + c.z * w01 + d.z * w11;
    r.w = a.w * w00 + b.w * w10 + c.w * w01 + d.w * w11;
    return r;
}

LT_DEV void put(LT_T const View& o, int x, int y, float a, float b, float c, float d)
{
    LT_G float* p = vpx(o, x, y); p[0] = a; p[1] = b; p[2] = c; p[3] = d;
}

// ---- kernels (one call = one output pixel) ---------------------------------------------

// Full-res source (+ depth) -> processing-res half frame. Area average; alpha = depth.
LT_DEV void kResample(int x, int y, LT_T const ResampleArgs& a)
{
    float sx = (float)a.src.w / a.dst.w, sy = (float)a.src.h / a.dst.h;
    int n = (int)LT_CEIL(sx), m = (int)LT_CEIL(sy);
    n = n < 1 ? 1 : (n > 8 ? 8 : n);
    m = m < 1 ? 1 : (m > 8 ? 8 : m);
    float r = 0, g = 0, b = 0, al = 0, mr = 0, mg = 0, mb = 0;
    for (int j = 0; j < m; ++j)
        for (int i = 0; i < n; ++i) {
            F4 c = ltS(a.src, (x + (i + 0.5f) / n) * sx, (y + (j + 0.5f) / m) * sy);
            r += c.x; g += c.y; b += c.z; al += c.w;
            mr = c.x > mr ? c.x : mr; mg = c.y > mg ? c.y : mg; mb = c.z > mb ? c.z : mb;
        }
    float inv = 1.0f / (n * m);
    // Lean toward the brightest tap so small hot lights survive the downscale.
    r = r * inv; g = g * inv; b = b * inv;
    r += 0.8f * (mr - r); g += 0.8f * (mg - g); b += 0.8f * (mb - b);
    float dep = 1.0f;
    if (a.depthMode == 1) {
        F4 d = ltS(a.depth, (x + 0.5f) / a.dst.w * a.depth.w, (y + 0.5f) / a.dst.h * a.depth.h);
        dep = 0.2126f * d.x + 0.7152f * d.y + 0.0722f * d.z;
    } else if (a.depthMode == 2) {
        dep = al * inv;
    }
    LT_G unsigned short* o = hpx(a.dst, x, y);
    o[0] = f2h(r); o[1] = f2h(g); o[2] = f2h(b); o[3] = f2h(dep);
}

// 32x32 sparse samples of a frame, for the cache fingerprint
LT_DEV void kFp(int x, int y, LT_T const FpArgs& a)
{
    int sx = (int)((x + 0.5f) / a.dst.w * a.src.w), sy = (int)((y + 0.5f) / a.dst.h * a.src.h);
    LT_G const unsigned short* s = hpx(a.src, sx, sy);
    put(a.dst, x, y, h2f(s[0]), h2f(s[1]), h2f(s[2]), h2f(s[3]));
}

// Highlight key: luma threshold, optional whites-only filter, optional depth band.
LT_DEV float keyBase(float r, float g, float b, float thresh, float soft, int colored)
{
    float y = 0.2126f * r + 0.7152f * g + 0.0722f * b;
    float k = smooth(thresh, thresh + soft, y);
    if (!colored) {
        float mx = r > g ? (r > b ? r : b) : (g > b ? g : b);
        float mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
        float sat = mx > 1e-6f ? (mx - mn) / mx : 0.0f;
        k *= 1.0f - smooth(0.45f, 0.8f, sat);         // warm whites pass, saturated neon does not
    }
    return k;
}

// Flicker: each region of frame (about 1/24 of its width) breathes and stutters on its own clock,
// so each lamp pulses independently. u, v normalized; the key and the composite use the same field.
LT_DEV float flickerGain(float u, float v, float aspect, float t, float amount, float speed)
{
    float cx = u * 24.0f, cy = v * 24.0f * aspect;
    float slow = ltNoise(cx + 3.1f, cy + 0.05f * speed * t);
    float fast = ltNoise(cx * 1.7f + 11.0f, cy * 1.7f + 0.35f * speed * t);
    float dip = smooth(0.15f, 0.55f, 0.6f * slow + 0.4f * fast);   // occasional deep stutters
    float g = 1.0f - amount * (0.3f * (0.5f + 0.5f * slow) + 0.7f * dip);
    return g < 0.0f ? 0.0f : g;
}

LT_DEV float keyWeight(float r, float g, float b, float dep, LT_T const KeyArgs& a)
{
    float k = keyBase(r, g, b, a.thresh, a.soft, a.colored);
    if (a.useDepth) {
        float d = a.invert ? 1.0f - dep : dep;
        k *= smooth(a.dLo - a.dFeather, a.dLo, d) * (1.0f - smooth(a.dHi, a.dHi + a.dFeather, d));
    }
    return k;
}

LT_DEV void kKey(int x, int y, LT_T const KeyArgs& a)
{
    LT_G const unsigned short* s = hpx(a.src, x, y);
    float r = h2f(s[0]), g = h2f(s[1]), b = h2f(s[2]), dep = h2f(s[3]);
    float k = keyWeight(r, g, b, dep, a);
    if (a.flicker > 0.0f && k > 0.0f)
        k *= flickerGain((x + 0.5f) / a.dst.w, (y + 0.5f) / a.dst.h, (float)a.dst.h / a.dst.w, a.ftime, a.flicker, a.flickSpeed);
    put(a.dst, x, y, r * k, g * k, b * k, k);
}

LT_DEV void kDown(int x, int y, LT_T const DownArgs& a)
{
    float sum = 0.0f;
    for (int j = 0; j < a.fdiv; ++j)
        for (int i = 0; i < a.fdiv; ++i)
            sum += texel(a.src, x * a.fdiv + i, y * a.fdiv + j).w;
    sum *= a.gain / (float)(a.fdiv * a.fdiv);
    put(a.dst, x, y, sum, sum, sum, 1.0f);
}

LT_DEV void kBlur(int x, int y, LT_T const BlurArgs& a)
{
    float inv = 1.0f / (2.0f * a.sigma * a.sigma);
    float s0 = 0, s1 = 0, s2 = 0, s3 = 0, ws = 0;
    for (int i = -a.radius; i <= a.radius; ++i) {
        float w = LT_EXP(-(float)(i * i) * inv);
        F4 c = texel(a.src, x + i * a.dx, y + i * a.dy);
        s0 += c.x * w; s1 += c.y * w; s2 += c.z * w; s3 += c.w * w; ws += w;
    }
    float n = 1.0f / ws;
    put(a.dst, x, y, s0 * n, s1 * n, s2 * n, s3 * n);
}

LT_DEV void kGrad(int x, int y, LT_T const GradArgs& a)
{
    float px = x + 0.5f, py = y + 0.5f;
    float fx = 0.0f, fy = 0.0f;
    if (a.useFlow) { LT_G const float* f = vpx(a.fl, x, y); fx = f[0]; fy = f[1]; }
    float qx = px + fx, qy = py + fy;
    float o0  = ltS(a.bo, px, py).x;
    float ixo = 0.5f * (ltS(a.bo, px + 1.0f, py).x - ltS(a.bo, px - 1.0f, py).x);
    float iyo = 0.5f * (ltS(a.bo, px, py + 1.0f).x - ltS(a.bo, px, py - 1.0f).x);
    float n0  = ltS(a.bn, qx, qy).x;
    float ixn = 0.5f * (ltS(a.bn, qx + 1.0f, qy).x - ltS(a.bn, qx - 1.0f, qy).x);
    float iyn = 0.5f * (ltS(a.bn, qx, qy + 1.0f).x - ltS(a.bn, qx, qy - 1.0f).x);
    float Ix = 0.5f * (ixo + ixn), Iy = 0.5f * (iyo + iyn), It = n0 - o0;
    if (a.mode == 0) put(a.dst, x, y, Ix * Ix, Ix * Iy, Iy * Iy, 1.0f);
    else             put(a.dst, x, y, Ix * It, Iy * It, 0.0f, 1.0f);
}

LT_DEV void kSolve(int x, int y, LT_T const SolveArgs& a)
{
    LT_G const float* A = vpx(a.p1, x, y);
    LT_G const float* B = vpx(a.p2, x, y);
    float pa = A[0], pb = A[1], pc = A[2];
    float tr = pa + pc;
    float det = pa * pc - pb * pb + 1.0e-4f * tr * tr + 1.0e-20f;
    float fx = -(pc * B[0] - pb * B[1]) / det;
    float fy = -(pa * B[1] - pb * B[0]) / det;
    if (a.useFlow) { LT_G const float* f = vpx(a.fl, x, y); fx += f[0]; fy += f[1]; }
    float m = LT_SQRT(fx * fx + fy * fy);
    if (m > a.lim) { float s = a.lim / m; fx *= s; fy *= s; }
    put(a.dst, x, y, fx, fy, 0.0f, 1.0f);
}

LT_DEV void kPrep(int x, int y, LT_T const PrepArgs& a)
{
    LT_G const float* f = vpx(a.fl, x, y);
    float c = vpx(a.bo, x, y)[0] + vpx(a.bn, x, y)[0];
    put(a.dst, x, y, f[0] * c, f[1] * c, c, 1.0f);
}

LT_DEV void kSmoke(int i, int j, LT_T const SmokeArgs& a)
{
    float zx = (float)(i * SMOKE_CELL) / a.scale, zy = (float)(j * SMOKE_CELL) / a.scale;
    put(a.dst, i, j,
        ltNoise(zx + 0.37f * a.ph, zy - 0.21f * a.age),
        ltNoise(zx - 0.29f * a.ph + 17.3f, zy + 0.23f * a.age + 5.1f), 0.0f, 0.0f);
}

LT_DEV void smokeAt(LT_T const View& g, float px, float py, LT_T float& sx, LT_T float& sy)
{
    float fx = px / SMOKE_CELL, fy = py / SMOKE_CELL;
    int i = (int)fx, j = (int)fy;
    if (i > g.w - 2) i = g.w - 2;
    if (j > g.h - 2) j = g.h - 2;
    if (i < 0) i = 0;
    if (j < 0) j = 0;
    float ax = fx - i, ay = fy - j;
    LT_G const float* a = vpx(g, i, j);
    LT_G const float* b = a + 4;
    LT_G const float* c = a + g.pitch;
    LT_G const float* d = c + 4;
    float w00 = (1 - ax) * (1 - ay), w10 = ax * (1 - ay), w01 = (1 - ax) * ay, w11 = ax * ay;
    sx = a[0] * w00 + b[0] * w10 + c[0] * w01 + d[0] * w11;
    sy = a[1] * w00 + b[1] * w10 + c[1] * w01 + d[1] * w11;
}

LT_DEV void kSmear(int x, int y, LT_T const SmearArgs& P)
{
    const float TAU = 6.2831853f;
    const float w = (float)P.hk.w, h = (float)P.hk.h;
    float px = x + 0.5f, py = y + 0.5f;
    F4 f = ltS(P.fs, px * P.fs.w / w, py * P.fs.h / h);
    float inv = P.flowScale / (f.z + 1.0e-6f);
    float vx = f.x * inv, vy = f.y * inv;          // motion over one echo step, processing px
    float dx = vx + P.driftX * P.stride, dy = vy + P.driftY * P.stride;
    float m = LT_SQRT(dx * dx + dy * dy);
    float tx = 1.0f, ty = 0.0f;
    if (m > 0.05f) { tx = dx / m; ty = dy / m; }
    float nx = -ty, ny = tx;

    int k = P.echo, S = P.samples;
    float N = (float)P.frames, ph = P.ph, amp = P.amp;
    if (P.variation > 0.0f) {
        float vn = (nx * px + ny * py) / P.varScale;
        ph  += 3.14159f * P.variation * ltNoise(vn, 7.3f);
        amp *= 1.0f + 0.6f * P.variation * ltNoise(vn + 41.7f, 5.9f);
    }
    float r = 0.0f, g = 0.0f, b = 0.0f;
    float s0x = 0, s0y = 0, s1x = 0, s1y = 0;
    if (P.useSmoke) { smokeAt(P.g0, px, py, s0x, s0y); smokeAt(P.g1, px, py, s1x, s1y); }
    for (int i = 0; i < S; i++) {
        float j = ltHash(x, y, k * 31 + i);
        float s = ((float)i + j) / (float)S;
        float age = ((float)(k - 1) + s) * P.stride;   // frames behind the light
        float a = age / N;
        float wv = fsin(TAU * P.freq * a - ph) + 0.45f * fsin(TAU * P.freq * 2.3f * a + 1.7f * ph + 1.3f);
        float jit = (P.thick + P.spread * a) * (2.0f * ltHash(x, y, k * 977 + i * 13) - 1.0f);
        float off = amp * a * wv + jit;
        float sx = 0.0f, sy = 0.0f;
        if (P.useSmoke) {
            float sa = P.smoke * amp * a;
            sx = sa * (s0x + (s1x - s0x) * s);
            sy = sa * (s0y + (s1y - s0y) * s);
        }
        float qx = px - s * vx - P.driftX * age - nx * off - sx;
        float qy = py - s * vy - P.driftY * age - ny * off - sy;
        if (qx < 0.0f || qy < 0.0f || qx >= w || qy >= h) continue;
        float dw = 1.0f;
        if (P.dissolve > 0.0f && a > 0.3f) {
            float en = ltNoise((px - s * vx) / P.emberScale + 0.5f * ph, (py - s * vy) / P.emberScale - 2.0f * a);
            float d = (a - 0.3f) * (1.0f / 0.7f);
            float th = -1.3f + 2.3f * P.dissolve * d;
            dw = smooth(th, th + 0.3f, en);
            if (dw <= 0.0f) continue;
        }
        F4 c = ltS(P.hk, qx, qy);
        c.x *= dw; c.y *= dw; c.z *= dw;
        float ca = a > 1.0f ? 1.0f : a;            // head -> tail colour along the trail
        r += c.x * (P.hR + (P.tR - P.hR) * ca);
        g += c.y * (P.hG + (P.tG - P.hG) * ca);
        b += c.z * (P.hB + (P.tB - P.hB) * ca);
    }
    float n = P.weight / (float)S;
    LT_G float* o = vpx(P.acc, x, y);
    if (P.first) { o[0] = r * n; o[1] = g * n; o[2] = b * n; o[3] = 1.0f; }
    else         { o[0] += r * n; o[1] += g * n; o[2] += b * n; }
}

// One straight-line gather for direction (dx, dy). sideSel: 0 none, +1 keep lights left of
// centre, -1 keep lights right of centre (soft band, so trails cross the middle).
LT_DEV void streakDir(int x, int y, LT_T const StreakArgs& a, float dx, float dy, int sideSel, int seed,
                      LT_T float& r, LT_T float& g, LT_T float& b, LT_T float& wsum, LT_T float& usum)
{
    const float TAU = 6.2831853f;
    const float w = (float)a.hk.w, h = (float)a.hk.h;
    const float band = 0.08f * w;
    float px = x + 0.5f, py = y + 0.5f;
    float nx = -dy, ny = dx;
    float jit0 = ltHash(x, y, 7 + seed);
    float len = a.len, amp = a.amp, ph = a.ph;
    if (a.variation > 0.0f) {
        // Variation: noise across the trail's direction is constant along a straight trail, so
        // each trail gets its own phase, length and wave height and they stop moving in lockstep.
        float vn = (nx * px + ny * py) / a.varScale;
        ph  += 3.14159f * a.variation * ltNoise(vn, 7.3f + 0.01f * seed);
        len *= 1.0f + 0.45f * a.variation * ltNoise(vn + 19.1f, 2.7f);
        amp *= 1.0f + 0.6f * a.variation * ltNoise(vn + 41.7f, 5.9f);
    }
#if defined(LT_LITE)
    // Smoke evaluated at 5 knots along the trail and interpolated: about a third of the cost.
    float kx[5] = {0, 0, 0, 0, 0}, ky[5] = {0, 0, 0, 0, 0};
    if (a.smoke > 0.0f)
        for (int j = 0; j < 5; ++j) {
            float uj = 0.25f * j, sj = uj * len;
            float zx = (px - dx * sj) / a.smokeScale, zy = (py - dy * sj) / a.smokeScale;
            float sa = a.smoke * amp * uj;
            kx[j] = sa * ltNoise(zx + 0.37f * ph, zy - 0.21f * uj * 4.0f);
            ky[j] = sa * ltNoise(zx - 0.29f * ph + 17.3f, zy + 0.23f * uj * 4.0f + 5.1f);
        }
#endif
    for (int i = 0; i < a.steps; ++i) {
        float u = ((float)i + jit0) / (float)a.steps;   // 0 at the light, 1 at the tail
        float s = u * len;
        float wv = fsin(TAU * a.freq * u - ph) + 0.45f * fsin(TAU * a.freq * 2.3f * u + 1.7f * ph + 1.3f);
        float off = amp * u * wv + (a.thick + a.spread * u) * (2.0f * ltHash(x, y, i * 13 + 1 + seed) - 1.0f);
        float bx = px - dx * s, by = py - dy * s;       // point on the straight trail
        float sx = 0.0f, sy = 0.0f;
#if defined(LT_LITE)
        // early out: this sample's light is on the wrong side of frame for this direction
        if (sideSel > 0 && bx > a.centerX + band) continue;
        if (sideSel < 0 && bx < a.centerX - band) continue;
        if (a.smoke > 0.0f) {
            float f = u * 4.0f;
            int j = (int)f; if (j > 3) j = 3;
            float t = f - (float)j;
            sx = kx[j] + (kx[j + 1] - kx[j]) * t;
            sy = ky[j] + (ky[j + 1] - ky[j]) * t;
        }
#else
        if (a.smoke > 0.0f) {
            float zx = bx / a.smokeScale, zy = by / a.smokeScale;
            float sa = a.smoke * amp * u;
            sx = sa * ltNoise(zx + 0.37f * ph, zy - 0.21f * u * 4.0f);
            sy = sa * ltNoise(zx - 0.29f * ph + 17.3f, zy + 0.23f * u * 4.0f + 5.1f);
        }
#endif
        float qx = bx - nx * off - sx, qy = by - ny * off - sy;
        if (qx < 0.0f || qy < 0.0f || qx >= w || qy >= h) continue;
        // falloff, plus a smooth fade over the last third so the tail never ends in a hard cut
        float wt = LT_EXP(-a.decayK * u) * (1.0f - smooth(0.65f, 1.0f, u));
        if (sideSel > 0) wt *= 1.0f - smooth(a.centerX - band, a.centerX + band, qx);   // light on the left
        else if (sideSel < 0) wt *= smooth(a.centerX - band, a.centerX + band, qx);    // light on the right
        if (wt <= 0.0f) continue;
        F4 c = ltS(a.hk, qx, qy);
        float lw = (c.x + c.y + c.z) * wt;               // how much this sample contributes
        wsum += lw; usum += lw * u;                       // -> average trail age at this pixel (Dissolve)
        r += c.x * wt * (a.hR + (a.tR - a.hR) * u);   // head -> tail colour along the trail
        g += c.y * wt * (a.hG + (a.tG - a.hG) * u);
        b += c.z * wt * (a.hB + (a.tB - a.hB) * u);
    }
}

LT_DEV void kStreak(int x, int y, LT_T const StreakArgs& a)
{
    float r = 0.0f, g = 0.0f, b = 0.0f, wsum = 0.0f, usum = 0.0f;
    if (a.mode == 2) {
        streakDir(x, y, a, a.dirX, a.dirY, 0, 0, r, g, b, wsum, usum);
    } else {
        // Inward: lights on the left trail right, lights on the right trail left. The side is
        // decided by where the light is, not where the pixel is, so there is no seam at the centre.
        streakDir(x, y, a, a.riseC, a.riseS, a.mode == 0 ? 1 : -1, 0, r, g, b, wsum, usum);
        streakDir(x, y, a, -a.riseC, a.riseS, a.mode == 0 ? -1 : 1, 101, r, g, b, wsum, usum);
    }
    if (a.dissolve > 0.0f && wsum > 0.0f) {
        // Dissolve: where the trail here is old (past its first 30%), break it into drifting embers.
        // One noise lookup per pixel, using the average age of what landed on it.
        float u = usum / wsum;
        if (u > 0.3f) {
            float d = (u - 0.3f) * (1.0f / 0.7f);
            float th = -1.3f + 2.3f * a.dissolve * d;
            float en = ltNoise((x + 0.5f) / a.emberScale + 0.5f * a.ph, (y + 0.5f) / a.emberScale - 2.0f * u);
            float m = smooth(th, th + 0.3f, en);
            r *= m; g *= m; b *= m;
        }
    }
    put(a.acc, x, y, r * a.norm, g * a.norm, b * a.norm, 1.0f);
}

LT_DEV void kComp(int x, int y, LT_T const CompArgs& a)
{
    int sx = x + a.offX, sy = y + a.offY;
    LT_G float* o = vpx(a.dst, x, y);
    if (sx < 0 || sy < 0 || sx >= a.src.w || sy >= a.src.h) { o[0] = o[1] = o[2] = o[3] = 0.0f; return; }
    LT_G const float* s = vpx(a.src, sx, sy);
    float u = (sx + 0.5f) / a.src.w, v = (sy + 0.5f) / a.src.h;
    if (a.showMask) {
        float k = ltS(a.mask, u * a.mask.w, v * a.mask.h).w;
        o[0] = k; o[1] = k; o[2] = k; o[3] = 1.0f;
        return;
    }
    float tr = 0, tg = 0, tb = 0;
    if (a.useAcc) {
        F4 t = ltS(a.acc, u * a.acc.w, v * a.acc.h);
        float cr = t.x, cb = t.z;
        if (a.fringe > 0.0f) {          // Fringe: red and blue pulled apart sideways, like VHS chroma bleed
            float du = a.fringe / a.src.w;
            cr = ltS(a.acc, (u - du) * a.acc.w, v * a.acc.h).x;
            cb = ltS(a.acc, (u + du) * a.acc.w, v * a.acc.h).z;
        }
        tr = cr * a.gain * (1.0f + 0.5f * a.warm);
        tg = t.y * a.gain;
        tb = cb * a.gain * (1.0f - 0.5f * a.warm);
        // Blend Softness: roll the trail's own highlights off (no hard clip) ...
        float k = ltSat(a.soft);
        if (k > 0.0f) {
            tr += k * ((1.0f - LT_EXP(-tr)) - tr);
            tg += k * ((1.0f - LT_EXP(-tg)) - tg);
            tb += k * ((1.0f - LT_EXP(-tb)) - tb);
        }
    }
    float r0 = s[0], g0 = s[1], b0 = s[2], a0 = s[3];
    float Y0 = 0.2126f * r0 + 0.7152f * g0 + 0.0722f * b0;
    if (a.flicker > 0.0f && a.blend != 2 && Y0 > a.kThresh) {   // the lamps flicker with their trails
        float kk = keyBase(r0, g0, b0, a.kThresh, a.kSoft, a.kColored);
        if (kk > 0.0f) {
            // dim only the brightness above the threshold, so the core always stays the brightest
            // part of the lamp (no dark ring) and a fully dipped lamp settles at threshold level
            float f = 1.0f - (1.0f - flickerGain(u, v, (float)a.src.h / a.src.w, a.ftime, a.flicker, a.flickSpeed)) * kk;
            float gl = (a.kThresh + (Y0 - a.kThresh) * f) / Y0;
            r0 *= gl; g0 *= gl; b0 *= gl;
        }
    }
    float k = ltSat(a.soft);
    if (a.blend == 2)      { o[0] = tr; o[1] = tg; o[2] = tb; o[3] = 1.0f; }
    else if (a.blend == 1) { o[0] = 1.0f - (1.0f - r0) * (1.0f - ltSat(tr));
                             o[1] = 1.0f - (1.0f - g0) * (1.0f - ltSat(tg));
                             o[2] = 1.0f - (1.0f - b0) * (1.0f - ltSat(tb)); o[3] = a0; }
    else {                 // ... and sink it into bright areas like screen, instead of stacking on top
        o[0] = r0 + tr * (1.0f - k * ltSat(r0));
        o[1] = g0 + tg * (1.0f - k * ltSat(g0));
        o[2] = b0 + tb * (1.0f - k * ltSat(b0));
        o[3] = a0;
    }
}

} // namespace ltk
