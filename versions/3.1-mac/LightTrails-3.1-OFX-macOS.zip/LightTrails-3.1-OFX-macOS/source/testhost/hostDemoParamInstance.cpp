/*
Software License :

Copyright (c) 2007, The Open Effects Association Ltd. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.
    * Neither the name The Open Effects Association Ltd, nor the names of its 
      contributors may be used to endorse or promote products derived from this
      software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <iostream>
#include <fstream>

// ofx
#include "ofxCore.h"
#include "ofxImageEffect.h"
#include "ofxPixels.h"

// ofx host
#include "ofxhBinary.h"
#include "ofxhPropertySuite.h"
#include "ofxhClip.h"
#include "ofxhParam.h"
#include "ofxhMemory.h"
#include "ofxhImageEffect.h"
#include "ofxhPluginAPICache.h"
#include "ofxhPluginCache.h"
#include "ofxhHost.h"
#include "ofxhImageEffectAPI.h"

// my host
#include "hostDemoHostDescriptor.h"
#include "hostDemoEffectInstance.h"
#include "hostDemoClipInstance.h"
#include "hostDemoParamInstance.h"

#include <map>
#include <string>
std::map<std::string, double> gParamOverrides;
static bool ovr(const std::string& n, double& v) { auto it = gParamOverrides.find(n); if (it == gParamOverrides.end()) return false; v = it->second; return true; }

namespace MyHost {

  //
  // MyIntegerInstance
  //

  MyIntegerInstance::MyIntegerInstance(MyEffectInstance* effect, 
                                       const std::string& name, 
                                       OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::IntegerInstance(descriptor, effect)
  {
  }

  OfxStatus MyIntegerInstance::get(int& v)
  {
    double o; if (ovr(getName(), o)) v = (int)o; else v = getProperties().getIntProperty(kOfxParamPropDefault);
    return kOfxStatOK;
  }

  OfxStatus MyIntegerInstance::get(OfxTime time, int& v)
  {
    double o; if (ovr(getName(), o)) v = (int)o; else v = getProperties().getIntProperty(kOfxParamPropDefault);
    return kOfxStatOK;
  }

  OfxStatus MyIntegerInstance::set(int v)
  {
    gParamOverrides[getName()] = v; return kOfxStatOK;
  }

  OfxStatus MyIntegerInstance::set(OfxTime time, int v)
  {
    gParamOverrides[getName()] = v; return kOfxStatOK;
  }

  //
  // MyDoubleInstance
  //

  MyDoubleInstance::MyDoubleInstance(MyEffectInstance* effect, 
                                     const std::string& name, 
                                     OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::DoubleInstance(descriptor, effect)
  {
  }

  OfxStatus MyDoubleInstance::get(double& v)
  {
    double o; if (ovr(getName(), o)) v = o; else v = getProperties().getDoubleProperty(kOfxParamPropDefault);
    return kOfxStatOK;
  }

  OfxStatus MyDoubleInstance::get(OfxTime time, double& v)
  {
    double o; if (ovr(getName(), o)) v = o; else v = getProperties().getDoubleProperty(kOfxParamPropDefault);
    return kOfxStatOK;
  }

  OfxStatus MyDoubleInstance::set(double v)
  {
    gParamOverrides[getName()] = v; return kOfxStatOK;
  }

  OfxStatus MyDoubleInstance::set(OfxTime time, double v)
  {
    gParamOverrides[getName()] = v; return kOfxStatOK;
  }

  OfxStatus MyDoubleInstance::derive(OfxTime time, double&)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyDoubleInstance::integrate(OfxTime time1, OfxTime time2, double&)
  {
    return kOfxStatErrMissingHostFeature;
  }

  //
  // MyBooleanInstance
  //

  MyBooleanInstance::MyBooleanInstance(MyEffectInstance* effect, 
                                       const std::string& name, 
                                       OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::BooleanInstance(descriptor, effect)
  {
  }

  OfxStatus MyBooleanInstance::get(bool& v)
  {
    double o; if (ovr(getName(), o)) v = o > 0.5; else v = getProperties().getIntProperty(kOfxParamPropDefault) != 0;
    return kOfxStatOK;
  }

  OfxStatus MyBooleanInstance::get(OfxTime time, bool& v)
  {
    double o; if (ovr(getName(), o)) v = o > 0.5; else v = getProperties().getIntProperty(kOfxParamPropDefault) != 0;
    return kOfxStatOK;
  }

  OfxStatus MyBooleanInstance::set(bool v)
  {
    gParamOverrides[getName()] = v ? 1 : 0; return kOfxStatOK;
  }

  OfxStatus MyBooleanInstance::set(OfxTime time, bool v)
  {
    gParamOverrides[getName()] = v ? 1 : 0; return kOfxStatOK;
  }

  //
  // MyChoiceInteger
  //

  MyChoiceInstance::MyChoiceInstance(MyEffectInstance* effect, 
                                     const std::string& name, 
                                     OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::ChoiceInstance(descriptor, effect)
  {
  }

  OfxStatus MyChoiceInstance::get(int& v)
  {
    double o; if (ovr(getName(), o)) v = (int)o; else v = getProperties().getIntProperty(kOfxParamPropDefault);
    return kOfxStatOK;
  }

  OfxStatus MyChoiceInstance::get(OfxTime time, int& v)
  {
    double o; if (ovr(getName(), o)) v = (int)o; else v = getProperties().getIntProperty(kOfxParamPropDefault);
    return kOfxStatOK;
  }

  OfxStatus MyChoiceInstance::set(int v)
  {
    gParamOverrides[getName()] = v; return kOfxStatOK;
  }

  OfxStatus MyChoiceInstance::set(OfxTime time, int v)
  {
    gParamOverrides[getName()] = v; return kOfxStatOK;
  }

  //
  // MyRGBAInstance
  //

  MyRGBAInstance::MyRGBAInstance(MyEffectInstance* effect, 
                                 const std::string& name, 
                                 OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::RGBAInstance(descriptor, effect)
  {
  }

  OfxStatus MyRGBAInstance::get(double&,double&,double&,double&)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyRGBAInstance::get(OfxTime time, double&,double&,double&,double&)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyRGBAInstance::set(double,double,double,double)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyRGBAInstance::set(OfxTime time, double,double,double,double)
  {
    return kOfxStatErrMissingHostFeature;
  }

  //
  // MyRGBInstance
  //

  MyRGBInstance::MyRGBInstance(MyEffectInstance* effect, 
                               const std::string& name, 
                               OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::RGBInstance(descriptor, effect)
  {
  }

  OfxStatus MyRGBInstance::get(double& r,double& g,double& b)
  {
    r = getProperties().getDoubleProperty(kOfxParamPropDefault, 0);
    g = getProperties().getDoubleProperty(kOfxParamPropDefault, 1);
    b = getProperties().getDoubleProperty(kOfxParamPropDefault, 2);
    double o;
    if (ovr(getName() + ".r", o)) r = o;
    if (ovr(getName() + ".g", o)) g = o;
    if (ovr(getName() + ".b", o)) b = o;
    return kOfxStatOK;
  }

  OfxStatus MyRGBInstance::get(OfxTime time, double& r,double& g,double& b)
  {
    r = getProperties().getDoubleProperty(kOfxParamPropDefault, 0);
    g = getProperties().getDoubleProperty(kOfxParamPropDefault, 1);
    b = getProperties().getDoubleProperty(kOfxParamPropDefault, 2);
    double o;
    if (ovr(getName() + ".r", o)) r = o;
    if (ovr(getName() + ".g", o)) g = o;
    if (ovr(getName() + ".b", o)) b = o;
    return kOfxStatOK;
  }

  OfxStatus MyRGBInstance::set(double r,double g,double b)
  {
    gParamOverrides[getName() + ".r"] = r; gParamOverrides[getName() + ".g"] = g; gParamOverrides[getName() + ".b"] = b;
    return kOfxStatOK;
  }

  OfxStatus MyRGBInstance::set(OfxTime time, double r,double g,double b)
  {
    gParamOverrides[getName() + ".r"] = r; gParamOverrides[getName() + ".g"] = g; gParamOverrides[getName() + ".b"] = b;
    return kOfxStatOK;
  }

  //
  // MyDouble2DInstance
  //

  MyDouble2DInstance::MyDouble2DInstance(MyEffectInstance* effect, 
                                         const std::string& name, 
                                         OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::Double2DInstance(descriptor, effect)
  {
  }

  OfxStatus MyDouble2DInstance::get(double& x,double& y)
  {
    // like a host that does not convert the normalised default: 0..1 comes back as-is
    x = getProperties().getDoubleProperty(kOfxParamPropDefault, 0);
    y = getProperties().getDoubleProperty(kOfxParamPropDefault, 1);
    double o;
    if (ovr(getName() + ".x", o)) x = o;
    if (ovr(getName() + ".y", o)) y = o;
    return kOfxStatOK;
  }

  OfxStatus MyDouble2DInstance::get(OfxTime time,double& x,double& y)
  {
    // like a host that does not convert the normalised default: 0..1 comes back as-is
    x = getProperties().getDoubleProperty(kOfxParamPropDefault, 0);
    y = getProperties().getDoubleProperty(kOfxParamPropDefault, 1);
    double o;
    if (ovr(getName() + ".x", o)) x = o;
    if (ovr(getName() + ".y", o)) y = o;
    return kOfxStatOK;
  }

  OfxStatus MyDouble2DInstance::set(double,double)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyDouble2DInstance::set(OfxTime time,double,double)
  {
    return kOfxStatErrMissingHostFeature;
  }

  //
  // MyInteger2DInstance
  //

  MyInteger2DInstance::MyInteger2DInstance(MyEffectInstance* effect, 
                                           const std::string& name, 
                                           OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::Integer2DInstance(descriptor, effect)
  {
  }

  OfxStatus MyInteger2DInstance::get(int&,int&)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyInteger2DInstance::get(OfxTime time,int&,int&)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyInteger2DInstance::set(int,int)
  {
    return kOfxStatErrMissingHostFeature;
  }

  OfxStatus MyInteger2DInstance::set(OfxTime time,int,int)
  {
    return kOfxStatErrMissingHostFeature;
  }

  //
  // MyInteger2DInstance
  //

  MyPushbuttonInstance::MyPushbuttonInstance(MyEffectInstance* effect, 
                                             const std::string& name, 
                                             OFX::Host::Param::Descriptor& descriptor)
    : _effect(effect), _descriptor(descriptor), OFX::Host::Param::PushbuttonInstance(descriptor, effect)
  {
  }

}
