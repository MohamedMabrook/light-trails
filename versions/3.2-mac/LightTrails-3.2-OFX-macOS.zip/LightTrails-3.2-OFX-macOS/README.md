# Light Trails 3.2 for Mac (Apple Silicon)

Same look and controls as Light Trails 3.2 for Windows: the on-screen reticle for Toward Point and Angle (drag it in the viewer), Seed and Randomize, Looks, Variation and Flicker, and **Color** and **Tail Color** (Look group: the trail blends from Color at the light to Tail Color at the tail), rebuilt for Apple Silicon and tuned lighter.

**Needs:** an Apple Silicon Mac (M1 or newer, built for M5-class GPUs) on macOS 13 or later, and DaVinci Resolve.

## Install

In **Terminal**, with Resolve closed:

```bash
curl -fsSL https://raw.githubusercontent.com/MohamedMabrook/light-trails/main/install-mac.sh | bash
```

It asks for your Mac password, because plugins live in `/Library/OFX/Plugins`. It backs up any older copy to `~/Library/Application Support/LightTrails/backup`, and clears the "downloaded from the internet" flag so macOS lets Resolve load the plugin.

To install by hand, copy `LightTrails.ofx.bundle` to `/Library/OFX/Plugins/`, then run `sudo xattr -dr com.apple.quarantine /Library/OFX/Plugins/LightTrails.ofx.bundle`.

Then in Resolve: **Color page → Effects → OpenFX → Light Trails**.

## Why it's lighter than the Windows build

- **Unified memory.** Frames are never copied between system memory and graphics memory, because on Apple Silicon they share the same memory. That copy is a fixed cost on every frame on Windows.
- **Lighter presets.** Low, Medium and High process fewer pixels and take fewer samples:

| Quality | Mac | Windows |
|---|---|---|
| Low | 25% resolution, 12 steps | 25% resolution, 16 steps |
| Medium | 40% resolution, 24 steps | 50% resolution, 32 steps |
| High | 60% resolution, 36 steps | 75% resolution, 48 steps |
| Final | 100% resolution, 64 steps | 100% resolution, 64 steps |

- **Cheaper smoke.** Smoke turbulence is computed at 5 points along each trail and blended between them.
- **Skip empty work.** Inward and Outward stop sampling where a trail can't reach.

In testing on the same machine, these make Medium about 1.8× lighter and Final about 1.9× lighter, with the same look.

## If something's off

The log is `~/Library/Logs/LightTrails.log`. You can also open it in the Console app, under Log Reports.

- **First line says `ready: Metal (Apple M5 …)`:** it's running on the GPU.
- **It says `Metal unavailable, using the CPU`:** the effect still works, just slower. Send me the log: the next line has the exact reason.
