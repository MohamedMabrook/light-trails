// Linux "Mac simulation" build: Metal is never available, so the Mac CPU fallback path runs.
#include "../src/LightTrailsCore.h"
namespace lt {
std::unique_ptr<Backend> makeMetalBackend(std::string& err) { err = "Metal not available (Linux test build)"; return nullptr; }
}
