# Builds the embedded Metal source: metal_stdlib + kernels header (LT_LITE) + entry points.
import sys
hdr, ent, out = sys.argv[1], sys.argv[2], sys.argv[3]
h = open(hdr).read().replace('#pragma once', '')
src = '#include <metal_stdlib>\nusing namespace metal;\n#define LT_LITE 1\n' + h + '\n' + open(ent).read()
open(out.replace('.h', '.metal'), 'w').write(src)
assert ')MSL"' not in src
open(out, 'w').write('// generated\nstatic const char kLightTrailsMetal[] = R"MSL(' + src + ')MSL";\n')
