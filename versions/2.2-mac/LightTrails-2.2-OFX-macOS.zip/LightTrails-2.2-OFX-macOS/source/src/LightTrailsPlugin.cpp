// LightTrailsPlugin.cpp
// OpenFX plugin for DaVinci Resolve. GPU only (CUDA). Uses Resolve's CUDA buffers directly
// when the host offers them; asks the host only for the history frames it has not cached.

#include <algorithm>
#include <cmath>
#include <cstring>
#include <list>
#include <memory>
#include <string>

#include "ofxsImageEffect.h"
#include "ofxsMultiThread.h"

#include "LightTrailsCore.h"

#define kPluginName        "Light Trails"
#define kPluginGrouping    "Light Trails"
#define kPluginDescription "Wavy, smoky trails that follow the motion of the hottest white lights. GPU (CUDA)."
#define kPluginIdentifier  "com.lighttrails.ofx.LightTrails"
#define kPluginVersionMajor 2
#define kPluginVersionMinor 2

static const int kMaxFrames = 24;
static const char* kDepthClip = "Depth";

// ---------------------------------------------------------------------------------------
// Host-memory conversion (only used when the host does not render in CUDA mode)
// ---------------------------------------------------------------------------------------
template <typename T> static inline float toF(T v);
template <> inline float toF<unsigned char>(unsigned char v) { return v / 255.0f; }
template <> inline float toF<unsigned short>(unsigned short v) { return v / 65535.0f; }
template <> inline float toF<float>(float v) { return v; }
template <typename T> static inline T fromF(float v);
template <> inline unsigned char fromF<unsigned char>(float v) { v = std::min(std::max(v, 0.0f), 1.0f); return (unsigned char)(v * 255.0f + 0.5f); }
template <> inline unsigned short fromF<unsigned short>(float v) { v = std::min(std::max(v, 0.0f), 1.0f); return (unsigned short)(v * 65535.0f + 0.5f); }
template <> inline float fromF<float>(float v) { return v; }

static int compsOf(const OFX::Image& im)
{
    switch (im.getPixelComponents()) {
        case OFX::ePixelComponentRGBA: return 4;
        case OFX::ePixelComponentRGB: return 3;
        case OFX::ePixelComponentAlpha: return 1;
        default: return 0;
    }
}

template <typename T>
static void readT(const OFX::Image& im, const OfxRectI& area, int nc, lt::Img& out)
{
    const int W = area.x2 - area.x1, H = area.y2 - area.y1;
    out.resize(W, H);
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x) {
            const T* p = static_cast<const T*>(im.getPixelAddress(area.x1 + x, area.y1 + y));
            float* o = out.px(x, y);
            if (!p) { o[0] = o[1] = o[2] = o[3] = 0.0f; continue; }
            if (nc == 1) { o[0] = o[1] = o[2] = o[3] = toF<T>(p[0]); continue; }
            o[0] = toF<T>(p[0]); o[1] = toF<T>(p[1]); o[2] = toF<T>(p[2]); o[3] = nc == 4 ? toF<T>(p[3]) : 1.0f;
        }
}
static bool readHost(const OFX::Image& im, const OfxRectI& area, lt::Img& out)
{
    int nc = compsOf(im);
    if (!nc) return false;
    switch (im.getPixelDepth()) {
        case OFX::eBitDepthUByte:  readT<unsigned char>(im, area, nc, out); return true;
        case OFX::eBitDepthUShort: readT<unsigned short>(im, area, nc, out); return true;
        case OFX::eBitDepthFloat:  readT<float>(im, area, nc, out); return true;
        default: return false;
    }
}
template <typename T>
static void writeT(OFX::Image& im, const OfxRectI& win, const OfxRectI& area, int nc, const lt::Img& src)
{
    for (int y = win.y1; y < win.y2; ++y)
        for (int x = win.x1; x < win.x2; ++x) {
            T* p = static_cast<T*>(im.getPixelAddress(x, y));
            if (!p) continue;
            int sx = x - area.x1, sy = y - area.y1;
            float c[4] = {0, 0, 0, 0};
            if (sx >= 0 && sy >= 0 && sx < src.w && sy < src.h) std::memcpy(c, src.px(sx, sy), 16);
            if (nc == 1) { p[0] = fromF<T>(c[3]); continue; }
            p[0] = fromF<T>(c[0]); p[1] = fromF<T>(c[1]); p[2] = fromF<T>(c[2]);
            if (nc == 4) p[3] = fromF<T>(c[3]);
        }
}
static bool writeHost(OFX::Image& im, const OfxRectI& win, const OfxRectI& area, const lt::Img& src)
{
    int nc = compsOf(im);
    if (!nc) return false;
    switch (im.getPixelDepth()) {
        case OFX::eBitDepthUByte:  writeT<unsigned char>(im, win, area, nc, src); return true;
        case OFX::eBitDepthUShort: writeT<unsigned short>(im, win, area, nc, src); return true;
        case OFX::eBitDepthFloat:  writeT<float>(im, win, area, nc, src); return true;
        default: return false;
    }
}

// A CUDA image from the host: float RGBA required.
static bool deviceView(OFX::Image& im, ltk::View& v)
{
    if (im.getPixelDepth() != OFX::eBitDepthFloat || im.getPixelComponents() != OFX::ePixelComponentRGBA) return false;
    const OfxRectI b = im.getBounds();
    v.d = static_cast<float*>(im.getPixelData());
    v.w = b.x2 - b.x1;
    v.h = b.y2 - b.y1;
    v.pitch = im.getRowBytes() / (int)sizeof(float);
    return v.d && v.w > 0 && v.h > 0 && v.pitch >= v.w * 4;
}

// ---------------------------------------------------------------------------------------
// Plugin instance
// ---------------------------------------------------------------------------------------
class LightTrailsPlugin : public OFX::ImageEffect {
public:
    explicit LightTrailsPlugin(OfxImageEffectHandle handle) : ImageEffect(handle)
    {
        dstClip_ = fetchClip(kOfxImageEffectOutputClipName);
        srcClip_ = fetchClip(kOfxImageEffectSimpleSourceClipName);
        depthClip_ = getContext() == OFX::eContextGeneral ? fetchClip(kDepthClip) : nullptr;

        quality_ = fetchChoiceParam("quality");
        gain_    = fetchDoubleParam("intensity");
        thresh_  = fetchDoubleParam("threshold");
        soft_    = fetchDoubleParam("softness");
        colored_ = fetchBooleanParam("coloredLights");
        mask_    = fetchBooleanParam("showMask");
        dir_     = fetchChoiceParam("direction");
        lenPct_  = fetchDoubleParam("length");
        decay_   = fetchDoubleParam("decay");
        rise_    = fetchDoubleParam("rise");
        angle_   = fetchDoubleParam("angle");
        frames_  = fetchIntParam("motionFrames");
        amp_     = fetchDoubleParam("waveAmplitude");
        freq_    = fetchDoubleParam("waveFrequency");
        speed_   = fetchDoubleParam("waveSpeed");
        smoke_   = fetchDoubleParam("smoke");
        width_   = fetchDoubleParam("width");
        warm_    = fetchDoubleParam("warmth");
        blend_   = fetchChoiceParam("blend");
        blendSoft_ = fetchDoubleParam("blendSoftness");
        dSrc_    = fetchChoiceParam("depthSource");
        dLo_     = fetchDoubleParam("depthFrom");
        dHi_     = fetchDoubleParam("depthTo");
        dFeather_= fetchDoubleParam("depthFeather");
        dInv_    = fetchBooleanParam("depthInvert");

        std::string err;
#if defined(__APPLE__) || defined(LT_MACSIM)
        // Mac: Metal on the GPU; if Metal cannot start, the CPU keeps the effect working.
        std::unique_ptr<lt::Backend> b = lt::makeMetalBackend(err);
        if (!b) {
            lt::logLine("Metal unavailable, using the CPU: " + err);
            b = lt::makeCpuBackend();
        }
#else
        std::unique_ptr<lt::Backend> b = lt::makeCudaBackend(err);
#endif
        if (b) {
            engine_.reset(new lt::Engine(std::move(b)));
            lt::logLine("ready: " + engine_->backendName());
        } else {
            gpuError_ = err;
            lt::logLine("GPU unavailable, passing image through: " + err);
        }
    }

    lt::Params paramsAt(double t) const
    {
        lt::Params p;
        int i = 0;
        quality_->getValueAtTime(t, i); p.quality = i;
        p.gain     = (float)gain_->getValueAtTime(t);
        p.thresh   = (float)thresh_->getValueAtTime(t);
        p.soft     = (float)soft_->getValueAtTime(t);
        p.colored  = colored_->getValueAtTime(t);
        p.showMask = mask_->getValueAtTime(t);
        dir_->getValueAtTime(t, i); p.direction = i;
        p.lengthPct = (float)lenPct_->getValueAtTime(t);
        p.decay    = (float)decay_->getValueAtTime(t);
        p.rise     = (float)rise_->getValueAtTime(t);
        p.angle    = (float)angle_->getValueAtTime(t);
        p.frames   = std::min(kMaxFrames, std::max(1, frames_->getValueAtTime(t)));
        p.amp      = (float)amp_->getValueAtTime(t);
        p.freq     = (float)freq_->getValueAtTime(t);
        p.speed    = (float)speed_->getValueAtTime(t);
        p.smoke    = (float)smoke_->getValueAtTime(t);
        p.width    = (float)width_->getValueAtTime(t);
        p.warm     = (float)warm_->getValueAtTime(t);
        blend_->getValueAtTime(t, i); p.blend = i;
        p.blendSoft = (float)blendSoft_->getValueAtTime(t);
        dSrc_->getValueAtTime(t, i); p.depthMode = i;
        p.dLo      = (float)dLo_->getValueAtTime(t);
        p.dHi      = (float)dHi_->getValueAtTime(t);
        p.dFeather = (float)dFeather_->getValueAtTime(t);
        p.dInvert  = dInv_->getValueAtTime(t);
        return p;
    }

    bool depthConnected() const { return depthClip_ && depthClip_->isConnected(); }

    // Only ask for history frames the GPU cache does not already hold.
    void getFramesNeeded(const OFX::FramesNeededArguments& args, OFX::FramesNeededSetter& frames) override
    {
        lt::Params p = paramsAt(args.time);
        int back = engine_ ? engine_->framesNeeded(args.time, p, lastW_, lastH_, depthConnected()) : 0;
        OfxRangeD r;
        r.min = args.time - back;
        r.max = args.time;
        frames.setFramesNeeded(*srcClip_, r);
        if (depthConnected()) frames.setFramesNeeded(*depthClip_, r);
    }

    void getRegionsOfInterest(const OFX::RegionsOfInterestArguments& args, OFX::RegionOfInterestSetter& rois) override
    {
        rois.setRegionOfInterest(*srcClip_, srcClip_->getRegionOfDefinition(args.time));
        if (depthConnected()) rois.setRegionOfInterest(*depthClip_, depthClip_->getRegionOfDefinition(args.time));
    }

    bool isIdentity(const OFX::IsIdentityArguments& args, OFX::Clip*& clip, double& time) override
    {
        if (!engine_ || (!mask_->getValueAtTime(args.time) && gain_->getValueAtTime(args.time) <= 0.0)) {
            clip = srcClip_;
            time = args.time;
            return true;
        }
        return false;
    }

    void render(const OFX::RenderArguments& args) override
    {
        std::unique_ptr<OFX::Image> dst(dstClip_->fetchImage(args.time));
        std::unique_ptr<OFX::Image> src(srcClip_->fetchImage(args.time));
        if (!dst || !src) OFX::throwSuiteStatusException(kOfxStatFailed);

        if (!engine_) {   // no GPU: hand the image through untouched (hosts normally skip us via isIdentity)
            lt::Img copy;
            if (args.cudaEnabled || !readHost(*src, src->getBounds(), copy) ||
                !writeHost(*dst, args.renderWindow, src->getBounds(), copy))
                OFX::throwSuiteStatusException(kOfxStatFailed);
            return;
        }

        const bool cuda = args.cudaEnabled;
        const OfxRectI area = src->getBounds();
        const lt::Params p = paramsAt(args.time);
        const bool wantDepth = p.depthMode == lt::DEPTH_INPUT && depthConnected();
        const OfxRangeD range = srcClip_->getFrameRange();

        // Everything fetched stays alive until the GPU work for this render has finished.
        std::list<std::unique_ptr<OFX::Image>> keep;
        std::list<lt::Img> hostImgs;

        auto toFrame = [&](OFX::Image* im, lt::Frame& f) -> bool {
            if (!im) return false;
            if (cuda) {
                f.onDevice = true;
                return deviceView(*im, f.view);
            }
            hostImgs.emplace_back();
            if (!readHost(*im, area, hostImgs.back())) return false;
            f.onDevice = false;
            f.host = &hostImgs.back();
            return true;
        };

        lt::Frame srcF, depF;
        if (!toFrame(src.get(), srcF)) OFX::throwSuiteStatusException(kOfxStatErrImageFormat);
        if (wantDepth) {
            keep.emplace_back(depthClip_->fetchImage(args.time));
            toFrame(keep.back().get(), depF);
        }

        lt::FetchFn fetch = [&](int back, lt::Frame& f, lt::Frame& d) -> bool {
            double t = args.time - back;
            if (t < range.min) return false;
            keep.emplace_back(srcClip_->fetchImage(t));
            if (!toFrame(keep.back().get(), f)) return false;
            if (wantDepth) {
                keep.emplace_back(depthClip_->fetchImage(t));
                toFrame(keep.back().get(), d);
            }
            return true;
        };

        lt::Output out;
        lt::Img hostOut;
        if (cuda) {
            out.onDevice = true;
            if (!deviceView(*dst, out.view)) OFX::throwSuiteStatusException(kOfxStatErrImageFormat);
            out.offX = dst->getBounds().x1 - area.x1;
            out.offY = dst->getBounds().y1 - area.y1;
        } else {
            out.host = &hostOut;
        }

        // Breadcrumbs: if the host ever goes down mid-render, the log shows exactly where.
        static const char* kDir[] = {"inward", "outward", "up", "angle", "motion"};
        lt::logLine("render t=" + std::to_string((int)args.time) + " " + kDir[std::min(4, std::max(0, p.direction))] +
                    " q=" + std::to_string(p.quality) + (cuda ? " cuda" : " host") + " " + std::to_string(srcF.w()) + "x" +
                    std::to_string(srcF.h()) + (cuda ? " pitch=" + std::to_string(srcF.view.pitch) : std::string()));
        bool ok = false;
        try {
            engine_->render(srcF, depF, args.time, (float)args.renderScale.x, p, fetch, out, cuda ? args.cudaStream : nullptr);
            ok = true;
        } catch (const std::exception& e) {
            lt::logLine(std::string("render failed: ") + e.what());
        } catch (...) {
            lt::logLine("render failed: unknown error");
        }
        if (!ok) OFX::throwSuiteStatusException(kOfxStatFailed);
        lastW_ = srcF.w();
        lastH_ = srcF.h();
        const lt::Stats& s = engine_->last;
        if (s.fetched || s.flushed)
            lt::logLine("t=" + std::to_string((int)args.time) + " fetched " + std::to_string(s.fetched) +
                        " frames, motion solved " + std::to_string(s.flowsSolved) + (s.flushed ? ", cache reset" : ""));

        if (!cuda && !writeHost(*dst, args.renderWindow, area, hostOut)) OFX::throwSuiteStatusException(kOfxStatErrImageFormat);
    }

private:
    OFX::Clip *dstClip_, *srcClip_, *depthClip_;
    OFX::ChoiceParam *quality_, *blend_, *dSrc_, *dir_;
    OFX::DoubleParam *gain_, *thresh_, *soft_, *decay_, *lenPct_, *rise_, *angle_, *amp_, *freq_, *speed_, *smoke_, *width_, *warm_;
    OFX::DoubleParam *dLo_, *dHi_, *dFeather_;
    OFX::BooleanParam *colored_, *mask_, *dInv_;
    OFX::IntParam* frames_;
    OFX::DoubleParam* blendSoft_;
    std::unique_ptr<lt::Engine> engine_;
    std::string gpuError_;
    int lastW_ = 0, lastH_ = 0;
};

// ---------------------------------------------------------------------------------------
// Description
// ---------------------------------------------------------------------------------------
using namespace OFX;

class LightTrailsFactory : public OFX::PluginFactoryHelper<LightTrailsFactory> {
public:
    LightTrailsFactory() : OFX::PluginFactoryHelper<LightTrailsFactory>(kPluginIdentifier, kPluginVersionMajor, kPluginVersionMinor) {}
    void describe(OFX::ImageEffectDescriptor& desc) override;
    void describeInContext(OFX::ImageEffectDescriptor& desc, OFX::ContextEnum context) override;
    OFX::ImageEffect* createInstance(OfxImageEffectHandle handle, OFX::ContextEnum context) override;
};

void LightTrailsFactory::describe(ImageEffectDescriptor& desc)
{
    desc.setLabels(kPluginName, kPluginName, kPluginName);
    desc.setPluginGrouping(kPluginGrouping);
    desc.setPluginDescription(kPluginDescription);
    desc.addSupportedContext(eContextFilter);
    desc.addSupportedContext(eContextGeneral);
    desc.addSupportedBitDepth(eBitDepthFloat);
    desc.addSupportedBitDepth(eBitDepthUShort);
    desc.addSupportedBitDepth(eBitDepthUByte);
    desc.setSingleInstance(false);
    desc.setHostFrameThreading(false);
    desc.setSupportsMultiResolution(true);
    desc.setSupportsTiles(false);
    desc.setTemporalClipAccess(true);
    desc.setRenderTwiceAlways(false);
    desc.setSupportsMultipleClipPARs(false);
    desc.setRenderThreadSafety(eRenderInstanceSafe);
    // Ask for Resolve's frames as CUDA memory, on its stream (OFX 1.5 / Resolve extension).
#if !defined(__APPLE__)
    desc.getPropertySet().propSetString("OfxImageEffectPropCudaRenderSupported", "true", 0, false);
    desc.getPropertySet().propSetString("OfxImageEffectPropCudaStreamSupported", "true", 0, false);
#endif
}

static DoubleParamDescriptor* dbl(ImageEffectDescriptor& d, const char* name, const char* label, const char* hint,
                                  double def, double lo, double hi, double dlo, double dhi, GroupParamDescriptor* grp)
{
    DoubleParamDescriptor* p = d.defineDoubleParam(name);
    p->setLabels(label, label, label);
    p->setHint(hint);
    p->setDefault(def);
    p->setRange(lo, hi);
    p->setDisplayRange(dlo, dhi);
    p->setIncrement((dhi - dlo) / 200.0);
    p->setDoubleType(eDoubleTypePlain);
    if (grp) p->setParent(*grp);
    return p;
}
static BooleanParamDescriptor* boolp(ImageEffectDescriptor& d, const char* name, const char* label, const char* hint,
                                     bool def, GroupParamDescriptor* grp)
{
    BooleanParamDescriptor* p = d.defineBooleanParam(name);
    p->setLabels(label, label, label);
    p->setHint(hint);
    p->setDefault(def);
    if (grp) p->setParent(*grp);
    return p;
}
static ChoiceParamDescriptor* choice(ImageEffectDescriptor& d, const char* name, const char* label, const char* hint,
                                     std::initializer_list<const char*> opts, int def, GroupParamDescriptor* grp)
{
    ChoiceParamDescriptor* p = d.defineChoiceParam(name);
    p->setLabels(label, label, label);
    p->setHint(hint);
    for (const char* o : opts) p->appendOption(o);
    p->setDefault(def);
    if (grp) p->setParent(*grp);
    return p;
}
static GroupParamDescriptor* group(ImageEffectDescriptor& d, const char* name, const char* label, bool open)
{
    GroupParamDescriptor* g = d.defineGroupParam(name);
    g->setLabels(label, label, label);
    g->setOpen(open);
    return g;
}

void LightTrailsFactory::describeInContext(ImageEffectDescriptor& desc, ContextEnum context)
{
    ClipDescriptor* src = desc.defineClip(kOfxImageEffectSimpleSourceClipName);
    src->addSupportedComponent(ePixelComponentRGBA);
    src->addSupportedComponent(ePixelComponentRGB);
    src->setTemporalClipAccess(true);
    src->setSupportsTiles(false);

    if (context == eContextGeneral) {
        ClipDescriptor* dep = desc.defineClip(kDepthClip);
        dep->addSupportedComponent(ePixelComponentRGBA);
        dep->addSupportedComponent(ePixelComponentRGB);
        dep->addSupportedComponent(ePixelComponentAlpha);
        dep->setTemporalClipAccess(true);
        dep->setSupportsTiles(false);
        dep->setOptional(true);
    }

    ClipDescriptor* dst = desc.defineClip(kOfxImageEffectOutputClipName);
    dst->addSupportedComponent(ePixelComponentRGBA);
    dst->addSupportedComponent(ePixelComponentRGB);
    dst->setSupportsTiles(false);

    PageParamDescriptor* page = desc.definePageParam("Controls");

    page->addChild(*choice(desc, "quality", "Quality",
        "Low: quarter resolution and every other frame, for setting the look. Medium and High: lighter than Final. Final: full quality for the render.",
        {"Low", "Medium", "High", "Final"}, 1, nullptr));
    page->addChild(*dbl(desc, "intensity", "Intensity", "Trail brightness. 0 turns the effect off.", 1.0, 0.0, 100.0, 0.0, 5.0, nullptr));

    GroupParamDescriptor* gH = group(desc, "grpHighlights", "Highlights", true);
    page->addChild(*dbl(desc, "threshold", "Threshold", "How hot a light must be to trail. Raise until only the lamps show in Show Mask.", 0.80, 0.0, 100.0, 0.0, 2.0, gH));
    page->addChild(*dbl(desc, "softness", "Softness", "Feathers the threshold.", 0.10, 0.001, 10.0, 0.001, 0.5, gH));
    page->addChild(*boolp(desc, "coloredLights", "Include Colored Lights", "Off: only white and warm-white lights trail. On: saturated lights (neon, brake lights) trail too.", false, gH));
    page->addChild(*boolp(desc, "showMask", "Show Mask", "Shows which lights will trail (threshold, color and depth combined).", false, gH));

    GroupParamDescriptor* gT = group(desc, "grpTrail", "Trail", true);
    page->addChild(*choice(desc, "direction", "Direction",
        "Inward: lamps at the sides trail toward the middle (the reference look). Outward, Up, Angle: fixed directions. "
        "All four work on still lights and need only the current frame. Follow Motion: trails come from where moving lights were (heavier).",
        {"Inward", "Outward", "Up", "Angle", "Follow Motion"}, 0, gT));
    page->addChild(*dbl(desc, "length", "Length", "Trail length, % of frame width (Inward, Outward, Up, Angle).", 12.0, 0.0, 100.0, 0.0, 40.0, gT));
    page->addChild(*dbl(desc, "decay", "Decay", "How much of the trail survives toward the tail. Higher = longer, brighter tail.", 0.85, 0.0, 1.0, 0.0, 1.0, gT));
    page->addChild(*dbl(desc, "rise", "Rise", "Tilt of Inward/Outward trails in degrees. Negative sinks.", 6.0, -90.0, 90.0, -45.0, 45.0, gT));
    page->addChild(*dbl(desc, "angle", "Angle", "Trail direction for Angle mode, degrees (0 right, 90 up).", 90.0, -360.0, 360.0, -180.0, 180.0, gT));
    IntParamDescriptor* mf = desc.defineIntParam("motionFrames");
    mf->setLabels("Motion Frames", "Motion Frames", "Motion Frames");
    mf->setHint("Follow Motion only: how many previous frames make the trail.");
    mf->setDefault(12);
    mf->setRange(1, kMaxFrames);
    mf->setDisplayRange(1, kMaxFrames);
    mf->setParent(*gT);
    page->addChild(*mf);

    GroupParamDescriptor* gL = group(desc, "grpLook", "Look", true);
    page->addChild(*dbl(desc, "waveAmplitude", "Wave", "Sideways wobble at the tail, in px. Zero at the light.", 20.0, 0.0, 1000.0, 0.0, 120.0, gL));
    page->addChild(*dbl(desc, "waveFrequency", "Wave Frequency", "Wave cycles along the trail.", 1.5, 0.0, 50.0, 0.0, 8.0, gL));
    page->addChild(*dbl(desc, "waveSpeed", "Wave Speed", "How fast the wave travels down the trail.", 0.15, -20.0, 20.0, -2.0, 2.0, gL));
    page->addChild(*dbl(desc, "smoke", "Smoke", "Turbulence that grows along the trail.", 0.5, 0.0, 20.0, 0.0, 3.0, gL));
    page->addChild(*dbl(desc, "width", "Width", "How much the trail widens and softens with age, in px.", 10.0, 0.0, 400.0, 0.0, 60.0, gL));
    page->addChild(*dbl(desc, "warmth", "Warmth", "Pushes the trails warm (+) or cool (-).", 0.2, -1.0, 1.0, -1.0, 1.0, gL));
    page->addChild(*choice(desc, "blend", "Blend", "How the trails combine with the image.", {"Add", "Screen", "Trails Only"}, 0, gL));
    page->addChild(*dbl(desc, "blendSoftness", "Blend Softness",
        "0: straight add, crisp and hot. Higher: the trails roll off instead of clipping and sink into bright areas like screen, for a softer, more photographic blend.",
        0.5, 0.0, 1.0, 0.0, 1.0, gL));

    GroupParamDescriptor* gD = group(desc, "grpDepth", "Depth", false);
    page->addChild(*choice(desc, "depthSource", "Depth Source",
        "Limit trails by depth. Depth Input: connect a depth map (white = near) to the node's second input. Alpha: use the image's alpha channel.",
        {"Off", "Depth Input", "Alpha Channel"}, 0, gD));
    page->addChild(*dbl(desc, "depthFrom", "Depth From", "Lowest depth value that trails.", 0.0, 0.0, 1.0, 0.0, 1.0, gD));
    page->addChild(*dbl(desc, "depthTo", "Depth To", "Highest depth value that trails.", 1.0, 0.0, 1.0, 0.0, 1.0, gD));
    page->addChild(*dbl(desc, "depthFeather", "Depth Feather", "Soft edge on both ends of the depth band.", 0.05, 0.0, 1.0, 0.0, 0.5, gD));
    page->addChild(*boolp(desc, "depthInvert", "Invert Depth", "Use when your depth map has black = near.", false, gD));

}

ImageEffect* LightTrailsFactory::createInstance(OfxImageEffectHandle handle, ContextEnum)
{
    return new LightTrailsPlugin(handle);
}

#if defined(__APPLE__)
#include <dlfcn.h>
// Keep this image loaded for the life of the host: a host that scans plugins and then unloads
// them must never run our static destructors while anything of ours is still referenced.
static void pinSelf()
{
    Dl_info info;
    if (dladdr((const void*)&pinSelf, &info) && info.dli_fname)
        dlopen(info.dli_fname, RTLD_NOLOAD | RTLD_NODELETE);
}
#endif

namespace OFX {
namespace Plugin {
void getPluginIDs(OFX::PluginFactoryArray& ids)
{
#if defined(__APPLE__)
    pinSelf();
#endif
    static LightTrailsFactory p;
    ids.push_back(&p);
}
} // namespace Plugin
} // namespace OFX
