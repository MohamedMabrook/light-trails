// LightTrailsMetal.cpp: Metal backend for Apple Silicon.
// Plain C++ talking to Metal through the Objective-C runtime (loaded at runtime), so it builds
// without the macOS SDK. Kernels are Metal Shading Language source compiled by the OS on first
// use. Buffers live in unified memory (storageModeShared): uploads and downloads are plain
// memcpy, there is no PCIe copy. Kernel arguments carry raw GPU addresses (Metal 3), which is
// what lets the shared engine treat Metal buffers exactly like CUDA pointers.
#include "LightTrailsCore.h"

#include <dlfcn.h>

#include <cstdint>
#include <cstring>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

#include "LightTrails_metal.h"   // generated: static const char kLightTrailsMetal[]

namespace lt {
namespace {

typedef void* id;
typedef void* SEL;
typedef unsigned long NSUInteger;
struct MTLSize { NSUInteger width, height, depth; };

struct Runtime {
    id (*getClass)(const char*) = nullptr;
    SEL (*selReg)(const char*) = nullptr;
    void* msgSend = nullptr;
    void* (*poolPush)() = nullptr;
    void (*poolPop)(void*) = nullptr;
    id (*createDevice)() = nullptr;
} R;

// objc_msgSend must be called through a cast to the exact prototype (arm64 ABI).
template <typename Ret, typename... A>
Ret M(id obj, const char* sel, A... a)
{
    return ((Ret(*)(id, SEL, A...))R.msgSend)(obj, R.selReg(sel), a...);
}
id cls(const char* n) { return R.getClass(n); }
id nsstr(const char* s) { return M<id>(cls("NSString"), "stringWithUTF8String:", s); }
std::string str(id ns)
{
    if (!ns) return std::string();
    const char* c = M<const char*>(ns, "UTF8String");
    return c ? std::string(c) : std::string();
}
std::string errText(id err) { return err ? str(M<id>(err, "localizedDescription")) : std::string("unknown error"); }

const size_t kArgSize[K_COUNT] = {
    sizeof(ltk::ResampleArgs), sizeof(ltk::FpArgs), sizeof(ltk::KeyArgs), sizeof(ltk::DownArgs),
    sizeof(ltk::BlurArgs), sizeof(ltk::GradArgs), sizeof(ltk::SolveArgs), sizeof(ltk::PrepArgs),
    sizeof(ltk::SmokeArgs), sizeof(ltk::SmearArgs), sizeof(ltk::CompArgs), sizeof(ltk::StreakArgs)};

const NSUInteger kMTLGPUFamilyMetal3 = 5001;
const NSUInteger kMTLLanguageVersion3_0 = 0x30000;
const NSUInteger kMTLResourceStorageModeShared = 0;
const NSUInteger kMTLResourceUsageReadWrite = 1 | 2;
const NSUInteger kMTLBarrierScopeBuffers = 1;
const NSUInteger kMTLCommandBufferStatusError = 5;

struct Buf { id obj; char* cpu; size_t size; };

class MetalBackend : public Backend {
public:
    bool init(std::string& err)
    {
        void* objc = dlopen("/usr/lib/libobjc.A.dylib", RTLD_NOW);
        void* found = dlopen("/System/Library/Frameworks/Foundation.framework/Foundation", RTLD_NOW);
        void* metal = dlopen("/System/Library/Frameworks/Metal.framework/Metal", RTLD_NOW);
        if (!objc || !found || !metal) { err = "could not load Metal / Objective-C runtime"; return false; }
        *(void**)&R.getClass = dlsym(objc, "objc_getClass");
        *(void**)&R.selReg = dlsym(objc, "sel_registerName");
        R.msgSend = dlsym(objc, "objc_msgSend");
        *(void**)&R.poolPush = dlsym(objc, "objc_autoreleasePoolPush");
        *(void**)&R.poolPop = dlsym(objc, "objc_autoreleasePoolPop");
        *(void**)&R.createDevice = dlsym(metal, "MTLCreateSystemDefaultDevice");
        if (!R.getClass || !R.selReg || !R.msgSend || !R.poolPush || !R.poolPop || !R.createDevice) {
            err = "Objective-C runtime or Metal symbols missing";
            return false;
        }

        void* pool = R.poolPush();
        bool ok = setup(err);
        R.poolPop(pool);
        return ok;
    }

    const std::string& name() const override { return name_; }

    void begin(void*, const void*) override { pool_ = R.poolPush(); }
    void end() override
    {
        try { sync(); } catch (const std::exception& e) { logLine(std::string("Metal: ") + e.what()); }
        if (pool_) { R.poolPop(pool_); pool_ = nullptr; }
    }
    bool contextChanged() const override { return false; }

    void* alloc(size_t n) override
    {
        if (n == 0) n = 16;
        id b = M<id>(dev_, "newBufferWithLength:options:", (NSUInteger)n, kMTLResourceStorageModeShared);
        if (!b) throw std::runtime_error("Metal buffer allocation failed (out of memory? try a lower Quality)");
        uint64_t gpu = M<uint64_t>(b, "gpuAddress");
        char* cpu = static_cast<char*>(M<void*>(b, "contents"));
        if (!gpu || !cpu) throw std::runtime_error("Metal buffer has no GPU address (needs macOS 13+, Apple GPU)");
        std::memset(cpu, 0, n);
        bufs_[gpu] = Buf{b, cpu, n};
        return reinterpret_cast<void*>(gpu);
    }
    void release(void* p) override
    {
        sync();
        auto it = bufs_.find(reinterpret_cast<uint64_t>(p));
        if (it == bufs_.end()) return;
        resident_.erase(it->second.obj);
        M<void>(it->second.obj, "release");
        bufs_.erase(it);
    }
    void upload(void* d, const void* s, size_t n) override
    {
        sync();   // the GPU may still be reading this buffer
        std::memcpy(host(d, n), s, n);
    }
    void download(void* d, const void* s, size_t n) override
    {
        sync();
        std::memcpy(d, host(s, n), n);
    }
    void checkDevice(const void* p, size_t bytes, const char* what) override
    {
        try { host(p, bytes); }
        catch (...) { throw std::runtime_error(std::string(what) + " is not a Light Trails GPU buffer"); }
    }

    void run(KernelId k, const void* args, int w, int h) override
    {
        if (!enc_) {
            cmd_ = M<id>(queue_, "commandBuffer");
            if (!cmd_) throw std::runtime_error("Metal: no command buffer");
            M<id>(cmd_, "retain");
            enc_ = M<id>(cmd_, "computeCommandEncoder");
            if (!enc_) throw std::runtime_error("Metal: no compute encoder");
            M<id>(enc_, "retain");
            resident_.clear();
        }
        // Kernels reach buffers through GPU addresses inside their arguments, so every buffer
        // must be made resident for this encoder.
        std::vector<id> add;
        for (auto& kv : bufs_)
            if (!resident_.count(kv.second.obj)) { add.push_back(kv.second.obj); resident_.insert(kv.second.obj); }
        if (!add.empty())
            M<void>(enc_, "useResources:count:usage:", (const id*)add.data(), (NSUInteger)add.size(), kMTLResourceUsageReadWrite);

        M<void>(enc_, "setComputePipelineState:", pso_[k]);
        M<void>(enc_, "setBytes:length:atIndex:", args, (NSUInteger)kArgSize[k], (NSUInteger)0);
        MTLSize grid = {(NSUInteger)w, (NSUInteger)h, 1};
        MTLSize tg = {tgw_[k], tgh_[k], 1};
        M<void>(enc_, "dispatchThreads:threadsPerThreadgroup:", grid, tg);
        M<void>(enc_, "memoryBarrierWithScope:", kMTLBarrierScopeBuffers);
    }

    void sync() override
    {
        if (!enc_) return;
        M<void>(enc_, "endEncoding");
        M<void>(enc_, "release");
        enc_ = nullptr;
        M<void>(cmd_, "commit");
        M<void>(cmd_, "waitUntilCompleted");
        NSUInteger st = M<NSUInteger>(cmd_, "status");
        std::string e = st == kMTLCommandBufferStatusError ? errText(M<id>(cmd_, "error")) : std::string();
        M<void>(cmd_, "release");
        cmd_ = nullptr;
        resident_.clear();
        if (!e.empty()) throw std::runtime_error("Metal command buffer failed: " + e);
    }

private:
    id dev_ = nullptr, queue_ = nullptr, lib_ = nullptr;
    id pso_[K_COUNT] = {};
    NSUInteger tgw_[K_COUNT] = {}, tgh_[K_COUNT] = {};
    id cmd_ = nullptr, enc_ = nullptr;
    void* pool_ = nullptr;
    std::map<uint64_t, Buf> bufs_;
    std::set<id> resident_;
    std::string name_ = "Metal";

    bool setup(std::string& err)
    {
        dev_ = R.createDevice();
        if (!dev_) { err = "no Metal device"; return false; }
        if (!M<bool>(dev_, "supportsFamily:", kMTLGPUFamilyMetal3)) { err = "GPU lacks Metal 3 (needs Apple Silicon, macOS 13+)"; return false; }
        name_ = "Metal (" + str(M<id>(dev_, "name")) + ")";
        queue_ = M<id>(dev_, "newCommandQueue");
        if (!queue_) { err = "no Metal command queue"; return false; }

        id opts = M<id>(M<id>(cls("MTLCompileOptions"), "alloc"), "init");
        M<void>(opts, "setLanguageVersion:", kMTLLanguageVersion3_0);
        id e = nullptr;
        lib_ = M<id>(dev_, "newLibraryWithSource:options:error:", nsstr(kLightTrailsMetal), opts, &e);
        M<void>(opts, "release");
        if (!lib_) {
            err = "Metal kernel compile failed: " + errText(e);
            return false;
        }
        for (int k = 0; k < K_COUNT; ++k) {
            id fn = M<id>(lib_, "newFunctionWithName:", nsstr(kKernelNames[k]));
            if (!fn) { err = std::string("missing Metal kernel ") + kKernelNames[k]; return false; }
            id pe = nullptr;
            pso_[k] = M<id>(dev_, "newComputePipelineStateWithFunction:error:", fn, &pe);
            M<void>(fn, "release");
            if (!pso_[k]) { err = std::string("Metal pipeline ") + kKernelNames[k] + ": " + errText(pe); return false; }
            NSUInteger maxT = M<NSUInteger>(pso_[k], "maxTotalThreadsPerThreadgroup");
            NSUInteger simd = M<NSUInteger>(pso_[k], "threadExecutionWidth");
            if (simd == 0) simd = 32;
            tgw_[k] = simd;
            tgh_[k] = maxT >= simd * 8 ? 8 : (maxT / simd > 0 ? maxT / simd : 1);
        }
        return true;
    }

    char* host(const void* p, size_t n)
    {
        uint64_t a = reinterpret_cast<uint64_t>(p);
        auto it = bufs_.upper_bound(a);
        if (it == bufs_.begin()) throw std::runtime_error("unknown Metal buffer");
        --it;
        if (a < it->first || a + n > it->first + it->second.size) throw std::runtime_error("Metal buffer range");
        return it->second.cpu + (a - it->first);
    }
};

} // namespace

std::unique_ptr<Backend> makeMetalBackend(std::string& err)
{
    std::unique_ptr<MetalBackend> b(new MetalBackend());
    if (!b->init(err)) return nullptr;
    return std::unique_ptr<Backend>(b.release());
}

} // namespace lt
