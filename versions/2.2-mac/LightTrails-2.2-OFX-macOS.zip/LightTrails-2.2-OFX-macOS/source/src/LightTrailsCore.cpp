// LightTrailsCore.cpp: GPU render pipeline and caches.
#include "LightTrailsCore.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <stdexcept>

namespace lt {

const char* const kKernelNames[K_COUNT] = {"gResample", "gFp", "gKey", "gDown", "gBlur", "gGrad",
                                           "gSolve", "gPrep", "gSmoke", "gSmear", "gComp", "gStreak"};

// Mac builds (LT_LITE) use lighter presets: lower processing resolution and fewer samples.
// Final is identical on both platforms.
QualityPreset qualityPreset(int q)
{
#if defined(LT_LITE)
    switch (q) {
        case Q_LOW:    return {0.25f, 2, 1, 2};
        case Q_MEDIUM: return {0.40f, 3, 2, 1};
        case Q_HIGH:   return {0.60f, 5, 2, 1};
        default:       return {1.00f, 8, 3, 1};
    }
#endif
    switch (q) {
        case Q_LOW:    return {0.25f, 2, 1, 2};   // quarter res, every other frame: look dev
        case Q_MEDIUM: return {0.50f, 4, 2, 1};
        case Q_HIGH:   return {0.75f, 6, 2, 1};
        default:       return {1.00f, 8, 3, 1};   // final
    }
}

int streakSteps(int quality)
{
#if defined(LT_LITE)
    static const int kSteps[4] = {12, 24, 36, 64};
#else
    static const int kSteps[4] = {16, 32, 48, 64};
#endif
    return kSteps[std::min(3, std::max(0, quality))];
}

void logLine(const std::string& s)
{
    static std::mutex m;
    std::lock_guard<std::mutex> l(m);
#if defined(__APPLE__)
    const char* home = getenv("HOME");                 // ~/Library/Logs shows up in Console.app
    std::string path = std::string(home ? home : "/tmp") + "/Library/Logs/LightTrails.log";
#else
    const char* dir = getenv("TEMP");
    if (!dir) dir = getenv("TMPDIR");
    if (!dir) dir = "/tmp";
    std::string path = std::string(dir) + "/LightTrails.log";
#endif
    FILE* f = fopen(path.c_str(), "a");
    if (!f) return;
    if (ftell(f) > 2 * 1024 * 1024) { fclose(f); f = fopen(path.c_str(), "w"); if (!f) return; }   // keep it small
    time_t t = time(nullptr);
    char ts[32];
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", localtime(&t));
    fprintf(f, "[%s] %s\n", ts, s.c_str());
    fclose(f);
}

static inline uint64_t mix(uint64_t h, uint64_t v) { h ^= v + 0x9e3779b97f4a7c15ull + (h << 6) + (h >> 2); return h; }
static inline uint64_t mixf(uint64_t h, float f) { uint32_t u; std::memcpy(&u, &f, 4); return mix(h, u); }

// ---------------------------------------------------------------------------------------
// Buffers
// ---------------------------------------------------------------------------------------
void* Engine::getBytes(size_t n)
{
    auto it = pool_.find(n);
    if (it != pool_.end() && !it->second.empty()) { void* p = it->second.back(); it->second.pop_back(); return p; }
    return be_->alloc(n);
}
void Engine::putBytes(void* p, size_t n) { if (p) pool_[n].push_back(p); }
ltk::View Engine::getV(int w, int h)
{
    ltk::View v = {static_cast<float*>(getBytes(size_t(w) * h * 16)), w, h, w * 4};
    return v;
}
void Engine::putV(const ltk::View& v) { putBytes(v.d, size_t(v.w) * v.h * 16); }
ltk::HView Engine::getH(int w, int h)
{
    ltk::HView v = {static_cast<unsigned short*>(getBytes(size_t(w) * h * 8)), w, h, w * 4};
    return v;
}
void Engine::putH(const ltk::HView& v) { putBytes(v.d, size_t(v.w) * v.h * 8); }

void Engine::flushAll()
{
    for (auto& kv : frames_) putH(kv.second.img);
    frames_.clear();
    for (auto& kv : flows_) putV(kv.second);
    flows_.clear(); flowOrder_.clear();
    gen_++;
    if (trail_.d) putV(trail_);
    trail_ = {nullptr, 0, 0, 0};
    trailKey_ = 0;
}

void Engine::forgetAll()   // buffers belong to a context we can no longer use: drop, don't free
{
    pool_.clear(); frames_.clear(); flows_.clear(); flowOrder_.clear();
    trail_ = {nullptr, 0, 0, 0}; trailKey_ = 0; frameSig_ = 0;
}

Engine::~Engine()
{
    try {
        be_->begin(nullptr, nullptr);
        flushAll();
        for (auto& kv : pool_) for (void* p : kv.second) be_->release(p);
        pool_.clear();
        be_->end();
    } catch (...) {}
}

uint64_t Engine::frameSig(int W, int H, const Params& p, bool hasDepth)
{
    uint64_t s = mix(mix(1, (uint64_t)W), (uint64_t)H);
    s = mix(s, (uint64_t)p.quality);
    s = mix(s, (uint64_t)(p.depthMode == DEPTH_INPUT && !hasDepth ? DEPTH_OFF : p.depthMode));
    return s;
}

int Engine::framesNeeded(double time, const Params& p, int W, int H, bool hasDepth)
{
    // Static directions use only the current frame. Follow Motion declares its whole window:
    // the cache saves the work, but the host must know every frame we might fetch.
    (void)time; (void)W; (void)H; (void)hasDepth;
    if (p.direction != DIR_MOTION || p.showMask) return 0;
    QualityPreset q = qualityPreset(p.quality);
    const int ne = std::max(1, (p.frames + q.stride - 1) / q.stride);
    return ne * q.stride;
}

// ---------------------------------------------------------------------------------------
// Render
// ---------------------------------------------------------------------------------------
void Engine::render(const Frame& src, const Frame& depthIn, double time, float rs, const Params& p,
                    const FetchFn& fetch, const Output& out, void* stream)
{
    std::lock_guard<std::mutex> lock(mtx_);
    last = Stats();
    be_->begin(stream, src.onDevice ? src.view.d : nullptr);
    struct End { Backend* b; ~End() { b->end(); } } endGuard{be_.get()};
    if (be_->contextChanged()) { forgetAll(); logLine("CUDA context changed; caches dropped"); }

    const int W = src.w(), H = src.h();
    const QualityPreset q = qualityPreset(p.quality);
    const int Pw = std::max(8, (int)std::lround(W * q.scale)), Ph = std::max(8, (int)std::lround(H * q.scale));
    const bool hasDepth = depthIn.valid();
    const int depthMode = (p.depthMode == DEPTH_INPUT && !hasDepth) ? DEPTH_OFF : p.depthMode;

    const uint64_t sig = frameSig(W, H, p, hasDepth);
    if (sig != frameSig_) { flushAll(); frameSig_ = sig; last.flushed = 1; }

    std::vector<std::pair<void*, size_t>> scratch;   // returned to the pool on exit
    struct Ret { Engine* e; std::vector<std::pair<void*, size_t>>* s; ~Ret() { for (auto& b : *s) e->putBytes(b.first, b.second); } } ret{this, &scratch};
    auto tmpV = [&](int w, int h) { ltk::View v = getV(w, h); scratch.push_back({v.d, size_t(w) * h * 16}); return v; };

    // Host frames are uploaded into reusable full-res staging buffers.
    ltk::View stageSrc = {nullptr, 0, 0, 0}, stageDep = {nullptr, 0, 0, 0};
    auto need = [](const ltk::View& v) { return ((size_t)(v.h - 1) * v.pitch + (size_t)v.w * 4) * 4; };
    auto devView = [&](const Frame& f, ltk::View& stage) -> ltk::View {
        if (f.onDevice) { be_->checkDevice(f.view.d, need(f.view), "host image"); return f.view; }
        if (!stage.d || stage.w != f.host->w || stage.h != f.host->h) stage = tmpV(f.host->w, f.host->h);
        be_->upload(stage.d, f.host->d.data(), size_t(stage.w) * stage.h * 16);
        return stage;
    };

    ltk::View fpBuf = tmpV(32, 32);
    std::vector<float> fpHost(32 * 32 * 4);
    auto fingerprint = [&](const ltk::HView& h) {
        ltk::FpArgs a = {h, fpBuf};
        be_->run(K_FP, &a, 32, 32);
        be_->sync();
        be_->download(fpHost.data(), fpBuf.d, fpHost.size() * 4);
        return fpHost;
    };
    auto hashOf = [](const std::vector<float>& v) {
        uint64_t x = 1469598103934665603ull;
        for (float f : v) { uint32_t u; std::memcpy(&u, &f, 4); x = (x ^ u) * 1099511628211ull; }
        return x;
    };
    // Mean difference between two fingerprints. Small changes (noise, grain) keep the history.
    auto differs = [](const std::vector<float>& a, const std::vector<float>& b) {
        if (a.size() != b.size()) return true;
        double d = 0.0;
        for (size_t i = 0; i < a.size(); ++i) {
            float x = std::min(std::max(a[i], -4.0f), 4.0f), y = std::min(std::max(b[i], -4.0f), 4.0f);
            d += std::fabs(x - y);
        }
        return d / a.size() > 0.01;
    };
    auto resample = [&](const Frame& f, const Frame& d) {
        ltk::View sv = devView(f, stageSrc);
        ltk::View dv = (depthMode == DEPTH_INPUT && d.valid()) ? devView(d, stageDep) : sv;
        ltk::HView h = getH(Pw, Ph);
        ltk::ResampleArgs a = {sv, dv, h, (depthMode == DEPTH_INPUT && !d.valid()) ? DEPTH_OFF : depthMode};
        be_->run(K_RESAMPLE, &a, Pw, Ph);
        return h;
    };

    // ---- current frame: fingerprint decides whether the history is still valid ----------
    const int64_t t = (int64_t)std::llround(time);
    ltk::HView cur = resample(src, depthIn);
    const std::vector<float> sCur = fingerprint(cur);
    const uint64_t curHash = hashOf(sCur);
    auto it = frames_.find(t);
    if (it != frames_.end() && differs(it->second.samples, sCur)) { flushAll(); last.flushed = 1; it = frames_.end(); }
    if (it == frames_.end()) frames_[t] = Entry{mix(gen_, (uint64_t)t), sCur, cur};
    else { putH(it->second.img); it->second.img = cur; it->second.samples = sCur; }   // newest pixels

    // ---- key setup ---------------------------------------------------------------------------
    ltk::KeyArgs ka;
    ka.thresh = p.thresh; ka.soft = std::max(0.001f, p.soft); ka.colored = p.colored ? 1 : 0;
    ka.useDepth = depthMode != DEPTH_OFF; ka.dLo = p.dLo; ka.dHi = p.dHi; ka.dFeather = std::max(0.0f, p.dFeather);
    ka.invert = p.dInvert ? 1 : 0;
    auto keyOf = [&](const ltk::HView& in, const ltk::View& dst) {
        ka.src = in; ka.dst = dst;
        be_->run(K_KEY, &ka, Pw, Ph);
    };

    ltk::View outV;
    if (out.onDevice) { outV = out.view; be_->checkDevice(outV.d, need(outV), "host output"); }
    else outV = tmpV(W, H);
    ltk::View srcV = devView(src, stageSrc);   // full-res source for compositing
    auto composite = [&](const ltk::View& acc, const ltk::View& mask, bool useAcc, bool showMask) {
        ltk::CompArgs c = {srcV, acc, mask, outV, out.offX, out.offY, useAcc ? 1 : 0, showMask ? 1 : 0,
                           p.blend, p.gain, p.warm, p.blendSoft};
        be_->run(K_COMP, &c, outV.w, outV.h);
        be_->sync();
        if (!out.onDevice) {
            out.host->resize(W, H);
            be_->download(out.host->d.data(), outV.d, size_t(W) * H * 16);
        }
    };

    if (p.showMask) {
        ltk::View hk = tmpV(Pw, Ph);
        keyOf(frames_[t].img, hk);
        composite(hk, hk, false, true);
        return;
    }

    // ---- static directions: one frame, one streak pass ---------------------------------------
    if (p.direction != DIR_MOTION) {
        const float ps = rs * (float)Pw / (float)W;
        uint64_t key = mix(mix(sig, curHash), (uint64_t)t * 2 + 1);
        float shape[] = {p.thresh, p.soft, (float)p.colored, p.dLo, p.dHi, p.dFeather, (float)p.dInvert, 2.2f,
                         (float)p.direction, p.lengthPct, p.rise, p.angle, p.decay,
                         p.amp, p.freq, p.speed, p.smoke, p.width, ps};
        for (float f : shape) key = mixf(key, f);
        if (trail_.d && trailKey_ == key && trail_.w == Pw && trail_.h == Ph) {
            last.trailHit = 1;
            composite(trail_, trail_, true, false);
            return;
        }
        ltk::View hk = tmpV(Pw, Ph);
        keyOf(frames_[t].img, hk);
        ltk::View acc = trail_.d && trail_.w == Pw && trail_.h == Ph ? trail_ : getV(Pw, Ph);
        if (trail_.d && acc.d != trail_.d) putV(trail_);
        trail_ = acc;
        trailKey_ = 0;

        const float DEG = 0.017453293f;
        ltk::StreakArgs a;
        a.hk = hk; a.acc = acc;
        a.steps = streakSteps(p.quality);
        a.len = std::max(1.0f, p.lengthPct / 100.0f * Pw);
        a.mode = (p.direction == DIR_INWARD) ? 0 : (p.direction == DIR_OUTWARD ? 1 : 2);
        float ang = (p.direction == DIR_UP ? 90.0f : p.angle) * DEG;
        a.dirX = std::cos(ang); a.dirY = std::sin(ang);
        a.riseC = std::cos(p.rise * DEG); a.riseS = std::sin(p.rise * DEG);
        a.centerX = 0.5f * Pw;
        a.decayK = -std::log(std::min(1.0f, std::max(1e-3f, p.decay))) * 12.0f;
        a.norm = (a.len / a.steps) / (0.01f * Pw);
        a.amp = p.amp * ps; a.freq = p.freq; a.ph = p.speed * (float)time;
        a.thick = 0.15f * p.width * ps; a.spread = p.width * ps;
        a.smoke = p.smoke; a.smokeScale = std::max(1.0f, 80.0f * ps);
        be_->run(K_STREAK, &a, Pw, Ph);
        {   // soften the sample scatter into smooth, smoky streaks
            float sigma = std::max(0.8f, 0.12f * p.width * ps);
            int radius = std::max(1, (int)std::ceil(sigma * 2.5f));
            ltk::View tv = getV(Pw, Ph);
            ltk::BlurArgs b0 = {acc, tv, 1, 0, radius, sigma};
            be_->run(K_BLUR, &b0, Pw, Ph);
            ltk::BlurArgs b1 = {tv, acc, 0, 1, radius, sigma};
            be_->run(K_BLUR, &b1, Pw, Ph);
            putV(tv);
        }
        trailKey_ = key;
        composite(acc, acc, true, false);
        return;
    }

    // ---- history ---------------------------------------------------------------------------
    const int stride = q.stride;
    const int ne = std::max(1, (p.frames + stride - 1) / stride);
    std::vector<const Entry*> hist(ne + 1);
    hist[0] = &frames_[t];
    for (int k = 1; k <= ne; ++k) {
        const int64_t tk = t - (int64_t)k * stride;
        auto e = frames_.find(tk);
        if (e == frames_.end()) {
            Frame f, d;
            if (fetch(k * stride, f, d) && f.valid() && f.w() == W && f.h() == H) {
                ltk::HView hf = resample(f, d);
                frames_[tk] = Entry{mix(gen_, (uint64_t)tk), fingerprint(hf), hf};
                e = frames_.find(tk);
                last.fetched++;
            }
        }
        hist[k] = (e != frames_.end()) ? &e->second : hist[k - 1];   // before clip start: hold
    }
    // keep the cache to what the next frames can use
    while (frames_.size() > size_t(ne + 6)) {
        auto far = frames_.begin();
        for (auto i = frames_.begin(); i != frames_.end(); ++i)
            if (std::llabs(i->first - t) > std::llabs(far->first - t)) far = i;
        bool used = false;
        for (auto* h : hist) used |= (h == &far->second);
        if (used) break;
        putH(far->second.img);
        frames_.erase(far);
    }

    // ---- trails: reuse the last result if nothing that shapes them changed --------------------
    const float ps = rs * (float)Pw / (float)W;                     // full-res px -> processing px
    uint64_t tk = mix(sig, (uint64_t)t);
    tk = mix(tk, curHash);
    for (const Entry* e : hist) tk = mix(tk, e->id);
    float shape[] = {p.thresh, p.soft, (float)p.colored, p.dLo, p.dHi, p.dFeather, (float)p.dInvert,
                     (float)p.frames, p.decay, p.driftX, p.driftY, p.amp, p.freq, p.speed, p.smoke, p.width, ps};
    for (float f : shape) tk = mixf(tk, f);
    if (trail_.d && trailKey_ == tk && trail_.w == Pw && trail_.h == Ph) {
        last.trailHit = 1;
        composite(trail_, trail_, true, false);
        return;
    }

    const float range = 40.0f * ps * stride;
    const int fdiv = std::max(1, (int)std::ceil(Pw / 480.0));      // motion field ~480 px wide at every Quality
    const int fw = std::max(1, Pw / fdiv), fh = std::max(1, Ph / fdiv);
    const float fsig = std::max(0.5f, range / fdiv);
    const float lowGain = 6.2831853f * fsig * fsig;
    const float ph = p.speed * (float)time;
    const bool useSmoke = p.smoke > 0.0f;
    uint64_t flowSig = mix(mixf(mixf(mixf(1, p.thresh), p.soft), range), (uint64_t)(fdiv * 16 + q.iters));
    flowSig = mixf(mixf(mixf(mix(flowSig, (uint64_t)ka.colored), p.dLo), p.dHi), p.dFeather + (p.dInvert ? 10.0f : 0.0f));

    auto blur = [&](const ltk::View& img, float sigma) {
        if (sigma < 0.3f) return;
        int radius = std::max(1, (int)std::ceil(sigma * 2.5f));
        ltk::View tv = getV(img.w, img.h);
        ltk::BlurArgs a = {img, tv, 1, 0, radius, sigma};
        be_->run(K_BLUR, &a, img.w, img.h);
        ltk::BlurArgs b = {tv, img, 0, 1, radius, sigma};
        be_->run(K_BLUR, &b, img.w, img.h);
        putV(tv);
    };
    auto lowKey = [&](const ltk::View& hk, const ltk::View& lo) {
        ltk::DownArgs a = {hk, lo, fdiv, lowGain};
        be_->run(K_DOWN, &a, fw, fh);
        blur(lo, fsig);
    };
    auto solveFlow = [&](const ltk::View& bo, const ltk::View& bn) {
        ltk::View fl = getV(fw, fh), nf = getV(fw, fh), p1 = getV(fw, fh), p2 = getV(fw, fh);
        bool have = false;
        for (int i = 0; i < q.iters; ++i) {
            ltk::GradArgs g0 = {bo, bn, have ? fl : bo, p1, 0, have ? 1 : 0};
            be_->run(K_GRAD, &g0, fw, fh);
            ltk::GradArgs g1 = {bo, bn, have ? fl : bo, p2, 1, have ? 1 : 0};
            be_->run(K_GRAD, &g1, fw, fh);
            blur(p1, fsig); blur(p2, fsig);
            ltk::SolveArgs s = {p1, p2, have ? fl : p1, nf, have ? 1 : 0, 2.5f * fsig};
            be_->run(K_SOLVE, &s, fw, fh);
            std::swap(fl, nf);
            have = true;
        }
        ltk::View pr = getV(fw, fh);
        ltk::PrepArgs pa = {fl, bo, bn, pr};
        be_->run(K_PREP, &pa, fw, fh);
        blur(pr, fsig);
        putV(fl); putV(nf); putV(p1); putV(p2);
        last.flowsSolved++;
        return pr;
    };

    ltk::View hk = tmpV(Pw, Ph), lo = tmpV(fw, fh), newLo = tmpV(fw, fh);
    const int gw = Pw / ltk::SMOKE_CELL + 2, gh = Ph / ltk::SMOKE_CELL + 2;
    ltk::View gPrev = tmpV(gw, gh), gNext = tmpV(gw, gh);
    ltk::View acc = trail_.d && trail_.w == Pw && trail_.h == Ph ? trail_ : getV(Pw, Ph);
    if (trail_.d && acc.d != trail_.d) putV(trail_);
    trail_ = acc;
    trailKey_ = 0;

    keyOf(hist[0]->img, hk);
    lowKey(hk, newLo);
    auto smoke = [&](const ltk::View& g, float age) {
        ltk::SmokeArgs a = {g, std::max(1.0f, 80.0f * ps), ph, age};
        be_->run(K_SMOKE, &a, gw, gh);
    };
    if (useSmoke) smoke(gPrev, 0.0f);

    for (int k = 1; k <= ne; ++k) {
        keyOf(hist[k]->img, hk);
        lowKey(hk, lo);
        uint64_t fk = mix(mix(flowSig, hist[k]->id), hist[k - 1]->id * 31ull + 7);
        ltk::View fs;
        auto f = flows_.find(fk);
        if (f != flows_.end()) fs = f->second;
        else {
            fs = solveFlow(lo, newLo);
            flows_[fk] = fs;
            flowOrder_.push_back(fk);
            while (flowOrder_.size() > size_t(ne + 4)) {
                auto old = flows_.find(flowOrder_.front());
                if (old != flows_.end()) { putV(old->second); flows_.erase(old); }
                flowOrder_.erase(flowOrder_.begin());
            }
        }
        if (useSmoke) smoke(gNext, (float)(k * stride));

        ltk::SmearArgs a;
        a.acc = acc; a.hk = hk; a.fs = fs; a.g0 = gPrev; a.g1 = gNext;
        a.first = (k == 1); a.useSmoke = useSmoke; a.echo = k; a.stride = stride;
        a.frames = std::max(1, p.frames); a.samples = q.samples;
        // each echo stands in for `stride` frames: give it their combined brightness
        float w = 0.0f;
        for (int s = 0; s < stride; ++s) w += std::pow(p.decay, (float)((k - 1) * stride + s));
        a.weight = w; a.flowScale = (float)fdiv;
        a.amp = p.amp * ps; a.freq = p.freq; a.ph = ph;
        a.thick = 0.15f * p.width * ps; a.spread = p.width * ps;
        a.driftX = p.driftX * ps; a.driftY = p.driftY * ps; a.smoke = p.smoke;
        be_->run(K_SMEAR, &a, Pw, Ph);

        std::swap(lo, newLo);
        if (useSmoke) std::swap(gPrev, gNext);
    }
    trailKey_ = tk;
    composite(acc, acc, true, false);
}

} // namespace lt
