# Light Trails 2.2: OpenFX for DaVinci Resolve (Windows, NVIDIA GPU)

Same engine as 2.1, with the "too digital" edges removed.

## What changed from 2.1

- **No seam down the middle of frame.** 2.1's Inward split the frame at its vertical centre line, so any trail reaching the middle was cut by a hard vertical edge. 2.2 decides the trail direction by which side the *light* is on, with a soft crossfade around the centre. Trails cross the middle and fade out naturally. Outward works the same way.
- **Soft tails.** Trails fade out smoothly over their last third instead of stopping dead at Length.
- **New: Blend Softness** (Look group, default 0.5).
  - **0:** straight add, which is crisp and hot.
  - **Higher:** the trails' brightest parts roll off instead of clipping, and they sink into bright areas the way screen does.
  - **1:** the softest, most photographic blend.
  - **Speed:** like Intensity, it only recomposites, so it's instant.
- **The GPU line is gone from the controls.** The device is still written to `%TEMP%\LightTrails.log`.

Everything else (Direction, Quality, Depth, the whites-only key, caching) is unchanged.

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the installer from https://github.com/MohamedMabrook/light-trails.
