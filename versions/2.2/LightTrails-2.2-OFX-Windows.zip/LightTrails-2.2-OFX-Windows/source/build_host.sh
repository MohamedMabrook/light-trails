#!/usr/bin/env bash
# Builds the test host. linux: native binary. windows: .exe for Wine.
set -euo pipefail
cd "$(dirname "$0")"
HS=../ofxsdk/openfx14/HostSupport
EX=$HS/expat-2.0.1/lib
SRC="testhost/*.cpp $(ls $HS/src/*.cpp | grep -v ofxhImageEffect.cpp)"
INC="-Itesthost -I$HS/include -I../ofxsdk/openfx14/include -I$EX"
TARGET=${1:-linux}
mkdir -p build/host-$TARGET
if [ "$TARGET" = linux ]; then
  gcc -O2 -c -DHAVE_EXPAT_CONFIG_H=0 -DXML_STATIC -DHAVE_MEMMOVE -DXML_NS -DXML_DTD -DXML_CONTEXT_BYTES=1024 -DBYTEORDER=1234 \
    $EX/xmlparse.c $EX/xmlrole.c $EX/xmltok.c -I$EX && mv xmlparse.o xmlrole.o xmltok.o build/host-linux/
  g++ -O2 -std=gnu++14 -w -DXML_STATIC $INC $SRC build/host-linux/*.o -ldl -o build/host-linux/ltHost
else
  x86_64-w64-mingw32-gcc-posix -O2 -c -DXML_STATIC -DHAVE_MEMMOVE -DXML_NS -DXML_DTD -DXML_CONTEXT_BYTES=1024 -DBYTEORDER=1234 \
    $EX/xmlparse.c $EX/xmlrole.c $EX/xmltok.c -I$EX && mv xmlparse.o xmlrole.o xmltok.o build/host-windows/
  x86_64-w64-mingw32-g++-posix -O2 -std=gnu++14 -w -DWINDOWS -DWIN64 -DXML_STATIC $INC $SRC build/host-windows/*.o -static -o build/host-windows/ltHost.exe
fi
echo built host-$TARGET
