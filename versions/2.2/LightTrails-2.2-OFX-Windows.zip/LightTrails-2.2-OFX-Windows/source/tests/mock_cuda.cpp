// mock_cuda: a fake NVIDIA driver (libcuda / nvcuda.dll) for testing the CUDA path without a GPU.
// Kernels run on CPU threads through the same per-pixel code, launched block by block like a grid.
// Strict checks: every image in kernel args must lie inside a live allocation (pitch-aware, float
// or half); arg sizes must match the PTX; launches need a current context; contexts must balance.
#include "../src/LightTrailsKernels.h"

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#ifdef _WIN32
#  define EXPORT extern "C" __declspec(dllexport)
#else
#  define EXPORT extern "C" __attribute__((visibility("default")))
#endif

typedef int CUresult;
static void* const CTX = (void*)0x1234;
static std::mutex g_m;
static std::map<unsigned long long, size_t> g_alloc;
static std::string g_ptx;
static std::atomic<int> g_depth(0), g_launches(0), g_syncs(0);
static size_t g_peak = 0, g_cur = 0;

static void fail(const char* what)
{
    fprintf(stderr, "MOCK CUDA VIOLATION: %s\n", what);
    fflush(stderr);
    abort();
}

static void report()
{
    fprintf(stderr, "mock: launches=%d syncs=%d peak device MB=%.1f live allocations=%zu (%.1f MB)\n",
            g_launches.load(), g_syncs.load(), g_peak / 1048576.0, g_alloc.size(), g_cur / 1048576.0);
}
struct AtExit { ~AtExit() { report(); } } g_atexit;

static void checkMem(const void* d, int w, int h, int pitch, size_t elem, const char* k, const char* f)
{
    std::lock_guard<std::mutex> l(g_m);
    unsigned long long p = (unsigned long long)d;
    auto it = g_alloc.upper_bound(p);
    if (it == g_alloc.begin()) { fprintf(stderr, "%s.%s ", k, f); fail("pointer is not device memory"); }
    --it;
    if (w <= 0 || h <= 0 || pitch < w * 4) { fprintf(stderr, "%s.%s %dx%d pitch %d ", k, f, w, h, pitch); fail("bad view shape"); }
    size_t need = ((size_t)(h - 1) * pitch + (size_t)w * 4) * elem;
    if (p < it->first || p + need > it->first + it->second) { fprintf(stderr, "%s.%s %dx%d ", k, f, w, h); fail("view exceeds allocation"); }
}
#define CV(v, k, f) checkMem((v).d, (v).w, (v).h, (v).pitch, 4, k, f)
#define CH(v, k, f) checkMem((v).d, (v).w, (v).h, (v).pitch, 2, k, f)

static size_t ptxParamSize(const char* name)
{
    std::string key = std::string(name) + "_param_0[";
    size_t at = g_ptx.find(key);
    return at == std::string::npos ? 0 : (size_t)atoi(g_ptx.c_str() + at + key.size());
}

struct Fn { int id; const char* name; size_t argSize; };
static Fn g_fns[] = {
    {0, "gResample", sizeof(ltk::ResampleArgs)}, {1, "gFp", sizeof(ltk::FpArgs)}, {2, "gKey", sizeof(ltk::KeyArgs)},
    {3, "gDown", sizeof(ltk::DownArgs)}, {4, "gBlur", sizeof(ltk::BlurArgs)}, {5, "gGrad", sizeof(ltk::GradArgs)},
    {6, "gSolve", sizeof(ltk::SolveArgs)}, {7, "gPrep", sizeof(ltk::PrepArgs)}, {8, "gSmoke", sizeof(ltk::SmokeArgs)},
    {9, "gSmear", sizeof(ltk::SmearArgs)}, {10, "gComp", sizeof(ltk::CompArgs)}, {11, "gStreak", sizeof(ltk::StreakArgs)},
};

EXPORT CUresult cuInit(unsigned) { return 0; }
EXPORT CUresult cuDeviceGetCount(int* n) { *n = 1; return 0; }
EXPORT CUresult cuDeviceGet(int* d, int i) { *d = i; return 0; }
EXPORT CUresult cuDeviceGetName(char* s, int n, int) { snprintf(s, n, "Mock RTX"); return 0; }
EXPORT CUresult cuDevicePrimaryCtxRetain(void** c, int) { *c = CTX; return 0; }
EXPORT CUresult cuCtxPushCurrent_v2(void* c) { if (c != CTX) fail("push of unknown context"); g_depth++; return 0; }
EXPORT CUresult cuCtxPopCurrent_v2(void** c) { if (g_depth <= 0) fail("pop without push"); g_depth--; if (c) *c = CTX; return 0; }
EXPORT CUresult cuCtxGetCurrent(void** c) { *c = g_depth > 0 ? CTX : nullptr; return 0; }
EXPORT CUresult cuPointerGetAttribute(void* out, int attr, unsigned long long p)
{
    std::lock_guard<std::mutex> l(g_m);
    if (attr != 1) return 1;
    auto it = g_alloc.upper_bound(p);
    if (it == g_alloc.begin()) return 1;   // CUDA_ERROR_INVALID_VALUE
    *(void**)out = CTX;
    return 0;
}
EXPORT CUresult cuModuleLoadDataEx(void** m, const void* img, unsigned, int*, void**)
{
    if (g_depth <= 0) fail("module load without context");
    g_ptx = (const char*)img;
    if (g_ptx.find(".target sm_") == std::string::npos) fail("module image is not PTX");
    *m = (void*)0x5678;
    return 0;
}
EXPORT CUresult cuModuleGetFunction(void** f, void*, const char* name)
{
    for (auto& fn : g_fns)
        if (!strcmp(fn.name, name)) {
            if (g_ptx.find(std::string(".entry ") + name + "(") == std::string::npos) fail("function not in PTX");
            if (ptxParamSize(name) != fn.argSize) { fprintf(stderr, "%s ptx=%zu host=%zu ", name, ptxParamSize(name), fn.argSize); fail("arg size mismatch"); }
            *f = &fn;
            return 0;
        }
    return 500;
}
EXPORT CUresult cuMemAlloc_v2(unsigned long long* p, size_t n)
{
    if (g_depth <= 0) fail("alloc without current context");
    std::lock_guard<std::mutex> l(g_m);
    void* m = calloc(1, n);
    *p = (unsigned long long)m;
    g_alloc[*p] = n;
    g_cur += n; if (g_cur > g_peak) g_peak = g_cur;
    return 0;
}
EXPORT CUresult cuMemFree_v2(unsigned long long p)
{
    std::lock_guard<std::mutex> l(g_m);
    auto it = g_alloc.find(p);
    if (it == g_alloc.end()) fail("free of unknown pointer");
    g_cur -= it->second;
    g_alloc.erase(it);
    free((void*)p);
    return 0;
}
EXPORT CUresult cuMemcpyHtoD_v2(unsigned long long d, const void* s, size_t n)
{
    { std::lock_guard<std::mutex> l(g_m); auto it = g_alloc.find(d); if (it == g_alloc.end() || n > it->second) fail("HtoD out of range"); }
    memcpy((void*)d, s, n);
    return 0;
}
EXPORT CUresult cuMemcpyDtoH_v2(void* d, unsigned long long s, size_t n)
{
    { std::lock_guard<std::mutex> l(g_m); auto it = g_alloc.find(s); if (it == g_alloc.end() || n > it->second) fail("DtoH out of range"); }
    memcpy(d, (void*)s, n);
    return 0;
}
EXPORT CUresult cuMemGetAddressRange_v2(unsigned long long* base, size_t* size, unsigned long long p)
{
    std::lock_guard<std::mutex> l(g_m);
    auto it = g_alloc.upper_bound(p);
    if (it == g_alloc.begin()) return 1;
    --it;
    if (p >= it->first + it->second) return 1;
    *base = it->first; *size = it->second;
    return 0;
}
EXPORT CUresult cuStreamSynchronize(void*) { g_syncs++; return 0; }
EXPORT CUresult cuCtxSynchronize() { g_syncs++; return 0; }
EXPORT CUresult cuGetErrorString(CUresult, const char** s) { *s = "mock error"; return 0; }

template <typename A, typename F>
static void grid(void** params, unsigned gx, unsigned gy, unsigned bx, unsigned by, int W, int H, F f)
{
    const A a = *static_cast<const A*>(params[0]);
    unsigned nt = std::max(1u, std::thread::hardware_concurrency());
    std::vector<std::thread> th;
    for (unsigned t = 0; t < nt; ++t)
        th.emplace_back([&, t] {
            for (unsigned byi = t; byi < gy; byi += nt)
                for (unsigned bxi = 0; bxi < gx; ++bxi)
                    for (unsigned ty = 0; ty < by; ++ty)
                        for (unsigned tx = 0; tx < bx; ++tx) {
                            int x = bxi * bx + tx, y = byi * by + ty;
                            if (x < W && y < H) f(x, y, a);
                        }
        });
    for (auto& t : th) t.join();
}

EXPORT CUresult cuLaunchKernel(void* f, unsigned gx, unsigned gy, unsigned gz, unsigned bx, unsigned by, unsigned bz,
                               unsigned shm, void* stream, void** params, void** extra)
{
    if (g_depth <= 0) fail("launch without current context");
    if (gz != 1 || bz != 1 || shm != 0 || extra) fail("unexpected launch config");
    if (bx * by > 1024) fail("block too large");
    g_launches++;
    Fn* fn = (Fn*)f;
    const char* k = fn->name;
    switch (fn->id) {
        case 0: { auto& a = *(ltk::ResampleArgs*)params[0]; CV(a.src, k, "src"); CH(a.dst, k, "dst"); if (a.depthMode == 1) CV(a.depth, k, "depth");
                  grid<ltk::ResampleArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kResample); break; }
        case 1: { auto& a = *(ltk::FpArgs*)params[0]; CH(a.src, k, "src"); CV(a.dst, k, "dst");
                  grid<ltk::FpArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kFp); break; }
        case 2: { auto& a = *(ltk::KeyArgs*)params[0]; CH(a.src, k, "src"); CV(a.dst, k, "dst");
                  grid<ltk::KeyArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kKey); break; }
        case 3: { auto& a = *(ltk::DownArgs*)params[0]; CV(a.src, k, "src"); CV(a.dst, k, "dst");
                  grid<ltk::DownArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kDown); break; }
        case 4: { auto& a = *(ltk::BlurArgs*)params[0]; CV(a.src, k, "src"); CV(a.dst, k, "dst"); if (a.src.d == a.dst.d) fail("blur in place");
                  grid<ltk::BlurArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kBlur); break; }
        case 5: { auto& a = *(ltk::GradArgs*)params[0]; CV(a.bo, k, "bo"); CV(a.bn, k, "bn"); CV(a.fl, k, "fl"); CV(a.dst, k, "dst");
                  grid<ltk::GradArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kGrad); break; }
        case 6: { auto& a = *(ltk::SolveArgs*)params[0]; CV(a.p1, k, "p1"); CV(a.p2, k, "p2"); CV(a.fl, k, "fl"); CV(a.dst, k, "dst");
                  if (a.useFlow && a.fl.d == a.dst.d) fail("solve in place");
                  grid<ltk::SolveArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kSolve); break; }
        case 7: { auto& a = *(ltk::PrepArgs*)params[0]; CV(a.fl, k, "fl"); CV(a.bo, k, "bo"); CV(a.bn, k, "bn"); CV(a.dst, k, "dst");
                  grid<ltk::PrepArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kPrep); break; }
        case 8: { auto& a = *(ltk::SmokeArgs*)params[0]; CV(a.dst, k, "dst");
                  grid<ltk::SmokeArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kSmoke); break; }
        case 9: { auto& a = *(ltk::SmearArgs*)params[0]; CV(a.acc, k, "acc"); CV(a.hk, k, "hk"); CV(a.fs, k, "fs");
                  if (a.useSmoke) { CV(a.g0, k, "g0"); CV(a.g1, k, "g1"); }
                  if (a.acc.d == a.hk.d) fail("smear acc aliases hk");
                  grid<ltk::SmearArgs>(params, gx, gy, bx, by, a.acc.w, a.acc.h, ltk::kSmear); break; }
        case 10: { auto& a = *(ltk::CompArgs*)params[0]; CV(a.src, k, "src"); CV(a.acc, k, "acc"); CV(a.mask, k, "mask"); CV(a.dst, k, "dst");
                   if (a.src.d == a.dst.d) fail("comp in place");
                   grid<ltk::CompArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kComp); break; }
        case 11: { auto& a = *(ltk::StreakArgs*)params[0]; CV(a.hk, k, "hk"); CV(a.acc, k, "acc");
                   if (a.acc.d == a.hk.d) fail("streak in place");
                   grid<ltk::StreakArgs>(params, gx, gy, bx, by, a.acc.w, a.acc.h, ltk::kStreak); break; }
        default: fail("unknown function");
    }
    return 0;
}

// Test helpers for the host (allocate "device" images the way Resolve would)
EXPORT void* mockDeviceAlloc(size_t n) { unsigned long long p; cuMemAlloc_v2(&p, n); return (void*)p; }
EXPORT void mockDeviceFree(void* p) { cuMemFree_v2((unsigned long long)p); }
EXPORT int mockLaunches() { return g_launches.load(); }
