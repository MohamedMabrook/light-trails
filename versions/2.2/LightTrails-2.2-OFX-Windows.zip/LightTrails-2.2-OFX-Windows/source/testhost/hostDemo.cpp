// ltHost: minimal OFX host (built on the OFX HostSupport library) that loads LightTrails,
// asks it which frames it needs, renders one frame from float RGBA files and writes the result.
// usage: ltHost <frameDir> <W> <H> <numFrames> <t> <out.f32> [param=value ...]
//        set OFX_PLUGIN_PATH to the folder holding LightTrails.ofx.bundle
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
#include <memory>
#include <sstream>
#include <string>

#include "ofxCore.h"
#include "ofxImageEffect.h"
#include "ofxhBinary.h"
#include "ofxhPropertySuite.h"
#include "ofxhClip.h"
#include "ofxhParam.h"
#include "ofxhMemory.h"
#include "ofxhImageEffect.h"
#include "ofxhPluginAPICache.h"
#include "ofxhPluginCache.h"
#include "ofxhHost.h"
#include "ofxhImageEffectAPI.h"
#include "hostDemoHostDescriptor.h"
#include "hostDemoEffectInstance.h"
#include "hostDemoClipInstance.h"

extern int gW, gH, gNumFrames;
extern std::string gFrameDir;
extern std::map<std::string, double> gParamOverrides;

#define CHECK(x) do { OfxStatus s_ = (x); if (s_ != kOfxStatOK && s_ != kOfxStatReplyDefault) { fprintf(stderr, "FAIL %s -> %d\n", #x, s_); return 1; } } while (0)

int main(int argc, char** argv)
{
    if (argc < 7) { fprintf(stderr, "usage\n"); return 2; }
    gFrameDir = argv[1]; gW = atoi(argv[2]); gH = atoi(argv[3]); gNumFrames = atoi(argv[4]);
    int t = atoi(argv[5]); std::string outPath = argv[6];
    for (int i = 7; i < argc; ++i) { std::string a = argv[i]; auto e = a.find('='); gParamOverrides[a.substr(0, e)] = atof(a.c_str() + e + 1); }

    OFX::Host::PluginCache::getPluginCache()->setCacheVersion("ltHostV1");
    MyHost::Host host;
    OFX::Host::ImageEffect::PluginCache cache(host);
    cache.registerInCache(*OFX::Host::PluginCache::getPluginCache());
    OFX::Host::PluginCache::getPluginCache()->scanPluginFiles();

    OFX::Host::ImageEffect::ImageEffectPlugin* plugin = cache.getPluginById("com.lighttrails.ofx.LightTrails");
    if (!plugin) { fprintf(stderr, "FAIL plugin not found\n"); cache.dumpToStdOut(); return 1; }
    printf("loaded plugin: %s  group: %s\n", plugin->getDescriptor().getLabel().c_str(),
           plugin->getDescriptor().getPluginGrouping().c_str());

    extern void hostCudaInit(); hostCudaInit();
    const char* ctxName = getenv("LT_DEPTH_DIR") ? kOfxImageEffectContextGeneral : kOfxImageEffectContextFilter;
    std::unique_ptr<OFX::Host::ImageEffect::Instance> inst(plugin->createInstance(ctxName, NULL));
    if (!inst) { fprintf(stderr, "FAIL createInstance\n"); return 1; }
    CHECK(inst->createInstanceAction());
    if (!inst->getClipPreferences()) { fprintf(stderr, "FAIL clip prefs\n"); return 1; }

    OfxPointD rs = {1.0, 1.0};
    OfxRectI win = {0, 0, gW, gH};
    OfxRectD roi = {0, 0, (double)gW, (double)gH};

    // Passes: "a=1,b=2;c=3" -> pass 0 uses the command line params, pass i applies set i on top.
    std::vector<std::string> passes(1);
    if (getenv("LT_PASSES")) {
        std::string all = getenv("LT_PASSES"), cur;
        for (char c : all) { if (c == ';') { passes.push_back(cur); cur.clear(); } else cur += c; }
        passes.push_back(cur);
    }
    int t0 = getenv("LT_SEQ_START") ? atoi(getenv("LT_SEQ_START")) : t;
    extern int gServed;
    for (size_t pi = 0; pi < passes.size(); ++pi) {
        std::string set = passes[pi];
        size_t pos = 0;
        while (pos < set.size()) {
            size_t e = set.find(',', pos); if (e == std::string::npos) e = set.size();
            std::string kv = set.substr(pos, e - pos);
            size_t q = kv.find('=');
            if (q != std::string::npos) gParamOverrides[kv.substr(0, q)] = atof(kv.c_str() + q + 1);
            pos = e + 1;
        }
        int first = pi == 0 ? t0 : t;
        CHECK(inst->beginRenderAction(first, t, 1.0, false, rs, true, false));
        for (int f = first; f <= t; ++f) {
            OFX::Host::ImageEffect::RangeMap needed;
            CHECK(inst->getFrameNeededAction(f, needed));
            double lo = f;
            for (auto& kv : needed) for (auto& r : kv.second) if (kv.first->getName() == "Source") lo = r.min;
            std::map<OFX::Host::ImageEffect::ClipInstance*, OfxRectD> rois;
            CHECK(inst->getRegionOfInterestAction(f, rs, roi, rois));
            gServed = 0;
            auto c0 = std::chrono::steady_clock::now();
            CHECK(inst->renderAction(f, kOfxImageFieldBoth, win, rs, true, false, false));
            auto c1 = std::chrono::steady_clock::now();
            printf("pass %zu [%s] frame %d: asked for frames %g..%d, source images served %d, %.0f ms\n", pi, set.c_str(), f, lo, f,
                   gServed, std::chrono::duration<double, std::milli>(c1 - c0).count());
        }
        CHECK(inst->endRenderAction(first, t, 1.0, false, rs, true, false));

        MyHost::MyClipInstance* out = dynamic_cast<MyHost::MyClipInstance*>(inst->getClip("Output"));
        MyHost::MyImage* img = out->getOutputImage();
        std::string path = outPath;
        if (pi > 0) path += "." + std::to_string(pi);
        FILE* fo = fopen(path.c_str(), "wb");
        for (int y = 0; y < gH; ++y) fwrite(img->pixel(0, y), 4, size_t(gW) * 4, fo);
        fclose(fo);
    }
    printf("rendered -> %s\n", outPath.c_str());
    inst.reset();
    OFX::Host::PluginCache::clearPluginCache();
    return 0;
}
