# Light Trails 3.1: OpenFX for DaVinci Resolve

## New in 3.1

- **Two new directions** (Trail → Direction):
  - **Toward Center:** every light trails toward the middle of the frame.
  - **Toward Point:** every light trails toward a point you place. Drag the **Point** crosshair in the viewer, or type its X and Y. Trails stop at the point, and lights on any side converge on it.
- **Seed** and **Randomize** (Character group). The seed reshuffles waves, smoke, flicker timing and variation; the same seed always gives the same result. **Randomize** picks a new seed. Seed 0 is the original pattern, identical to 3.0.
- **Color** and **Tail Color** now live in the **Trail** group.
- **Removed:** Dissolve, Ember Size and Fringe, including their code.

Everything else is as in 3.0. With default settings, 3.1 renders exactly like 2.3 and 3.0 (checked bit for bit).

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the installer at https://github.com/MohamedMabrook/light-trails. Version 3.0 stays available there, and the `backup-v3.0` branch keeps its exact state.
