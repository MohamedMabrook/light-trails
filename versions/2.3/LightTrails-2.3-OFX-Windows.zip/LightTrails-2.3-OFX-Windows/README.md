# Light Trails 2.3: OpenFX for DaVinci Resolve (Windows, NVIDIA GPU)

Everything from 2.2, plus trail colour.

## New in 2.3: Color and Tail Color (Look group)

- **Color** tints the trail near the light, the bright core.
- **Tail Color** tints the wavy, smoky end.
- The trail blends smoothly from Color to Tail Color along its length. For example, a warm core can fade into cold blue smoke.
- Both default to white, so existing grades render exactly as in 2.2 (checked bit for bit).
- The colours multiply each light's own colour: a warm lamp with a blue Tail Color fades to a cool grey-blue. For a stronger shift, pick a more saturated colour.
- Changing a colour only redraws the trails. No frames are refetched.

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the installer at https://github.com/MohamedMabrook/light-trails.
