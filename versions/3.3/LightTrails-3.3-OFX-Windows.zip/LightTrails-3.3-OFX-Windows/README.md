# Light Trails 3.3: OpenFX for DaVinci Resolve

## New in 3.3

In the **Look** group:

- **Density** (0 to 1) splits each trail into parallel wisps, each with its own wave. At 0 you get one trail, as before. At 1 you get six intertwined strands, like a smoky rope. Higher density takes more samples, so it costs up to about 3× on the trail pass.
- **Blur** (px) softens the trail layer only, never the image. Thin trails get dimmer as they spread, so raise Intensity to compensate.
- **Focus** (0 to 1) is depth of field for the trails. Trails near the Point reticle stay sharp and go soft further away. It works with every Direction, so drag the reticle onto whatever should stay in focus.

In the **Trail** group:

- **Show Reticle** (on by default) draws the orange reticle into the picture itself, so it's visible on any viewer, including ones where Resolve doesn't show plugin overlays. It appears for Toward Point, Angle, or whenever Focus is above 0. **It's part of the image while it's on, so turn it off before you render.** The draggable viewer reticle from 3.2 is still there, and now also shows when Focus is on.

With Density, Blur and Focus at 0, renders are identical to 3.2.

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the installer at https://github.com/MohamedMabrook/light-trails. 3.2 stays available there (branch `backup-v3.2`).
