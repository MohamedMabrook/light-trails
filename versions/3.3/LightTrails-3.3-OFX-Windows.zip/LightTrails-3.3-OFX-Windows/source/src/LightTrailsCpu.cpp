// LightTrailsCpu.cpp: CPU backend. On the Mac it is the safety net if Metal cannot start;
// it runs the same per-pixel kernels on every core.
#include "LightTrailsCore.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <thread>
#include <vector>

namespace lt {
namespace {

void parallelRows(int h, const std::function<void(int, int)>& fn)
{
    unsigned n = std::max(1u, std::thread::hardware_concurrency());
    n = std::min<unsigned>(n, (unsigned)std::max(1, h / 4));
    if (n <= 1) { fn(0, h); return; }
    std::vector<std::thread> th;
    th.reserve(n);
    for (unsigned i = 0; i < n; ++i) {
        int y0 = int((long long)h * i / n), y1 = int((long long)h * (i + 1) / n);
        th.emplace_back([&fn, y0, y1] { fn(y0, y1); });
    }
    for (auto& t : th) t.join();
}

class CpuBackend : public Backend {
public:
    const std::string& name() const override { static const std::string n("CPU"); return n; }
    void begin(void*, const void*) override {}
    void end() override {}
    bool contextChanged() const override { return false; }
    void* alloc(size_t n) override
    {
        void* p = std::calloc(1, n);
        if (!p) throw std::runtime_error("out of memory");
        return p;
    }
    void release(void* p) override { std::free(p); }
    void upload(void* d, const void* s, size_t n) override { std::memcpy(d, s, n); }
    void download(void* d, const void* s, size_t n) override { std::memcpy(d, s, n); }
    void sync() override {}
    void checkDevice(const void*, size_t, const char*) override {}

    template <typename A, typename F>
    static void loop(const void* args, int w, int h, F f)
    {
        const A& a = *static_cast<const A*>(args);
        parallelRows(h, [&](int y0, int y1) {
            for (int y = y0; y < y1; ++y)
                for (int x = 0; x < w; ++x) f(x, y, a);
        });
    }
    // LT_PROFILE=1 (tests): time per kernel, printed when the backend is destroyed
    double prof_[K_COUNT] = {};
    ~CpuBackend() override
    {
        if (!getenv("LT_PROFILE")) return;
        for (int k = 0; k < K_COUNT; ++k)
            if (prof_[k] > 0) fprintf(stderr, "profile %-10s %8.1f ms\n", kKernelNames[k], prof_[k]);
    }
    void run(KernelId k, const void* a, int w, int h) override
    {
        auto t0 = std::chrono::steady_clock::now();
        runK(k, a, w, h);
        prof_[k] += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    }
    void runK(KernelId k, const void* a, int w, int h)
    {
        switch (k) {
            case K_RESAMPLE: loop<ltk::ResampleArgs>(a, w, h, ltk::kResample); break;
            case K_FP:       loop<ltk::FpArgs>(a, w, h, ltk::kFp); break;
            case K_KEY:      loop<ltk::KeyArgs>(a, w, h, ltk::kKey); break;
            case K_DOWN:     loop<ltk::DownArgs>(a, w, h, ltk::kDown); break;
            case K_BLUR:     loop<ltk::BlurArgs>(a, w, h, ltk::kBlur); break;
            case K_GRAD:     loop<ltk::GradArgs>(a, w, h, ltk::kGrad); break;
            case K_SOLVE:    loop<ltk::SolveArgs>(a, w, h, ltk::kSolve); break;
            case K_PREP:     loop<ltk::PrepArgs>(a, w, h, ltk::kPrep); break;
            case K_SMOKE:    loop<ltk::SmokeArgs>(a, w, h, ltk::kSmoke); break;
            case K_SMEAR:    loop<ltk::SmearArgs>(a, w, h, ltk::kSmear); break;
            case K_COMP:     loop<ltk::CompArgs>(a, w, h, ltk::kComp); break;
            case K_STREAK:   loop<ltk::StreakArgs>(a, w, h, ltk::kStreak); break;
            default: throw std::runtime_error("bad kernel id");
        }
    }
};

} // namespace

std::unique_ptr<Backend> makeCpuBackend() { return std::unique_ptr<Backend>(new CpuBackend()); }

} // namespace lt
