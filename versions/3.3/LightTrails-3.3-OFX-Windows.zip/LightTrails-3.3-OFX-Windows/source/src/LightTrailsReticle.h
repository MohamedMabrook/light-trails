// LightTrailsReticle.h: on-screen reticle for the Direction control (pure geometry, no OFX/GL).
// Coordinates are OFX canonical (pixels at full resolution, origin bottom-left, y up).
//  - Toward Point: the reticle is the point; dragging moves it.
//  - Angle:        the reticle sits on a ring around the frame centre; dragging sets the angle.
//  - other directions: hidden.
#pragma once
#include <cmath>

namespace ltr {

enum { DIR_ANGLE = 3, DIR_POINT = 6 };

struct Rect { double x1, y1, x2, y2; };
struct Geom {
    bool visible = false, angleMode = false;
    double x = 0, y = 0;            // reticle position
    double cx = 0, cy = 0, r = 0;   // ring centre and radius (Angle)
};

// The Point parameter can come back normalised (0..1) from hosts that do not convert the
// default; treat such values as a fraction of the frame. Same rule as the renderer.
inline void canonicalPoint(double& px, double& py, const Rect& rod)
{
    if (px >= 0.0 && px <= 1.0 && py >= 0.0 && py <= 1.0) {
        px = rod.x1 + px * (rod.x2 - rod.x1);
        py = rod.y1 + py * (rod.y2 - rod.y1);
    }
}

inline Geom geometry(int direction, double px, double py, double angleDeg, const Rect& rod)
{
    Geom g;
    g.cx = 0.5 * (rod.x1 + rod.x2);
    g.cy = 0.5 * (rod.y1 + rod.y2);
    g.r = 0.25 * std::fmin(rod.x2 - rod.x1, rod.y2 - rod.y1);
    if (direction == DIR_POINT) {
        canonicalPoint(px, py, rod);
        g.visible = true;
        g.x = px; g.y = py;
    } else if (direction == DIR_ANGLE) {
        const double a = angleDeg * 3.14159265358979 / 180.0;
        g.visible = true;
        g.angleMode = true;
        g.x = g.cx + g.r * std::cos(a);
        g.y = g.cy + g.r * std::sin(a);
    }
    return g;
}

// All handles on screen: the Angle ring (Angle), and the point (Toward Point, or any
// direction while Focus is on, since Focus is sharp around the point). Point first: it wins a grab.
inline int handles(int direction, double px, double py, double angleDeg, bool focusOn, const Rect& rod, Geom out[2])
{
    int n = 0;
    if (direction == DIR_POINT || focusOn) out[n++] = geometry(DIR_POINT, px, py, angleDeg, rod);
    if (direction == DIR_ANGLE) out[n++] = geometry(DIR_ANGLE, px, py, angleDeg, rod);
    return n;
}

// Grab radius: 22 screen pixels around the reticle (pixelScale = canonical units per screen px).
inline bool hit(const Geom& g, double penX, double penY, double pixelScale)
{
    if (!g.visible) return false;
    const double dx = penX - g.x, dy = penY - g.y, rad = 22.0 * pixelScale;
    return dx * dx + dy * dy <= rad * rad;
}

// Angle mode: the direction from the frame centre to the pen, in degrees (0 right, 90 up).
inline double angleFromPen(const Geom& g, double penX, double penY)
{
    return std::atan2(penY - g.cy, penX - g.cx) * 180.0 / 3.14159265358979;
}

// Point mode: keep the point inside the frame.
inline void clampToFrame(double& x, double& y, const Rect& rod)
{
    x = std::fmin(std::fmax(x, rod.x1), rod.x2);
    y = std::fmin(std::fmax(y, rod.y1), rod.y2);
}

} // namespace ltr
