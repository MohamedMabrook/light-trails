/* Fake libGL for tests: records the overlay's drawing so we can check what it would draw. */
#include <stdio.h>
#include <math.h>
static int prim = -1, nverts = 0, nprims = 0, kinds[4];
static double minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
static float lastR, lastG, lastB;
void glColor4f(float r, float g, float b, float a) { lastR = r; lastG = g; lastB = b; (void)a; }
void glLineWidth(float w) { (void)w; }
void glPointSize(float s) { (void)s; }
void glBegin(unsigned m) { prim = (int)m; nprims++; if (m < 4) kinds[m]++; }
void glEnd(void) { prim = -1; }
void glVertex2d(double x, double y) { nverts++; if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y; }
__attribute__((destructor)) static void report(void) {
    if (!nprims) return;
    fprintf(stderr, "fakegl: %d primitives (points %d, lines %d, loops %d, strips %d), %d vertices, bbox x %.1f..%.1f y %.1f..%.1f, last colour %.2f %.2f %.2f\n",
            nprims, kinds[0], kinds[1], kinds[2], kinds[3], nverts, minx, maxx, miny, maxy, lastR, lastG, lastB);
}
