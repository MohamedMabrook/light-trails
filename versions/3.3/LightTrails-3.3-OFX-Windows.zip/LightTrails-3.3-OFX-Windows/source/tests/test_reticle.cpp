// Unit tests for the reticle geometry (what the overlay draws and how drags map to params).
#include "../src/LightTrailsReticle.h"
#include <cstdio>
#include <cmath>
#include <initializer_list>
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s (line %d)\n", #c, __LINE__); ++fails; } } while (0)
static bool near(double a, double b, double e = 1e-6) { return std::fabs(a - b) < e; }
int main()
{
    ltr::Rect rod{0, 0, 3840, 2160};
    // hidden for directions without a reticle
    for (int d : {0, 1, 2, 4, 5}) CHECK(!ltr::geometry(d, 100, 100, 0, rod).visible);
    // Toward Point: reticle at the point; normalised default -> frame centre
    ltr::Geom g = ltr::geometry(ltr::DIR_POINT, 0.5, 0.5, 0, rod);
    CHECK(g.visible && near(g.x, 1920) && near(g.y, 1080));
    g = ltr::geometry(ltr::DIR_POINT, 3000, 500, 0, rod);
    CHECK(near(g.x, 3000) && near(g.y, 500) && !g.angleMode);
    // hit test: 22 screen px; at 2x zoom-out (pixelScale 2) that is 44 canonical px
    CHECK(ltr::hit(g, 3010, 505, 1.0));
    CHECK(!ltr::hit(g, 3030, 500, 1.0));
    CHECK(ltr::hit(g, 3030, 500, 2.0));
    // drag clamps to the frame
    double x = -50, y = 2500; ltr::clampToFrame(x, y, rod);
    CHECK(near(x, 0) && near(y, 2160));
    // Angle: reticle on a ring (radius = quarter of the short side) around the centre
    g = ltr::geometry(ltr::DIR_ANGLE, 0, 0, 90, rod);
    CHECK(g.visible && g.angleMode && near(g.r, 540) && near(g.x, 1920, 1e-3) && near(g.y, 1620, 1e-3));
    g = ltr::geometry(ltr::DIR_ANGLE, 0, 0, 0, rod);
    CHECK(near(g.x, 2460, 1e-3) && near(g.y, 1080, 1e-3));
    // dragging sets the angle from the centre: right = 0, up = 90, left = 180, down = -90
    CHECK(near(ltr::angleFromPen(g, 2500, 1080), 0));
    CHECK(near(ltr::angleFromPen(g, 1920, 1500), 90));
    CHECK(near(std::fabs(ltr::angleFromPen(g, 1000, 1080)), 180));
    CHECK(near(ltr::angleFromPen(g, 1920, 100), -90));
    CHECK(near(ltr::angleFromPen(g, 1920 + 300, 1080 + 300), 45));
    // round trip: angle -> reticle -> drag at the reticle gives the same angle
    for (double a : {-170.0, -45.0, 10.0, 133.0}) {
        ltr::Geom q = ltr::geometry(ltr::DIR_ANGLE, 0, 0, a, rod);
        CHECK(near(ltr::angleFromPen(q, q.x, q.y), a, 1e-6));
    }
    // offset frames (image origin not at 0,0)
    ltr::Rect off{100, 50, 2020, 1130};
    g = ltr::geometry(ltr::DIR_POINT, 0.25, 0.75, 0, off);
    CHECK(near(g.x, 100 + 0.25 * 1920) && near(g.y, 50 + 0.75 * 1080));
    // handles: point shows for Toward Point or whenever Focus is on; Angle adds the ring handle
    ltr::Geom hs[2];
    CHECK(ltr::handles(0, 500, 500, 0, false, rod, hs) == 0);
    CHECK(ltr::handles(0, 500, 500, 0, true, rod, hs) == 1 && !hs[0].angleMode && near(hs[0].x, 500));
    CHECK(ltr::handles(ltr::DIR_POINT, 500, 500, 0, true, rod, hs) == 1);
    CHECK(ltr::handles(ltr::DIR_ANGLE, 500, 500, 90, true, rod, hs) == 2 && !hs[0].angleMode && hs[1].angleMode);
    CHECK(ltr::handles(ltr::DIR_ANGLE, 500, 500, 90, false, rod, hs) == 1 && hs[0].angleMode);
    printf(fails ? "%d reticle test(s) FAILED\n" : "all reticle tests passed\n", fails);
    return fails ? 1 : 0;
}
