# Light Trails 3.0: OpenFX for DaVinci Resolve

Everything from 2.3, plus character controls and one-click Looks. Every new control defaults to off, so 3.0 opens looking exactly like 2.3 (checked bit for bit).

## New

**Looks** (top of the panel): Custom, Analog Horror, Sodium Haze, Neon Rain, Dream, Subtle. Picking one sets the trail, look and character controls. Everything stays editable afterwards. Custom leaves your settings alone.

**Character** group:

| Control | What it does |
|---|---|
| **Variation** | Each trail gets its own wave phase, length and height, so they stop moving in lockstep. |
| **Flicker** / **Flicker Speed** | Lamps and their trails breathe and stutter, each on its own timing, like failing sodium lights. Only the brightness above the threshold dims, so a dipped lamp stays a clean disc. |
| **Dissolve** / **Ember Size** | Past the first 30% of its length, the trail breaks into drifting embers and wisps. |
| **Fringe** | Pulls red and blue apart sideways along the trails, like VHS colour bleed. Instant to change. |

## Cost

All four together add about 3 to 11% at Medium, measured on the streak and composite stages. Dissolve and Flicker are close to free. Variation is about 5%, and Fringe is within measurement noise. Looks cost nothing; they only set values.

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the installer at https://github.com/MohamedMabrook/light-trails. Version 2.3 stays available there, and the `backup-v2.3` branch keeps its exact state.
