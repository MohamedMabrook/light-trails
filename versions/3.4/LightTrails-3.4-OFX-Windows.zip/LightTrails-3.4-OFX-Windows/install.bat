@echo off
rem Installs Light Trails 3.4 for DaVinci Resolve (OpenFX). Needs administrator rights.
net session >nul 2>&1
if errorlevel 1 (
  echo Right-click install.bat and choose "Run as administrator".
  pause
  exit /b 1
)
set "DEST=%CommonProgramFiles%\OFX\Plugins"
if not exist "%DEST%" mkdir "%DEST%"
xcopy /E /I /Y "%~dp0LightTrails.ofx.bundle" "%DEST%\LightTrails.ofx.bundle" >nul
if errorlevel 1 (
  echo Copy failed. Close DaVinci Resolve and try again.
  pause
  exit /b 1
)
echo Installed to %DEST%\LightTrails.ofx.bundle
echo Restart DaVinci Resolve, then look under OpenFX ^> Light Trails.
pause
